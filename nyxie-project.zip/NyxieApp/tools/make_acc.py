"""Génère les dessins vectoriels des accessoires (chemins SVG en coordonnées de l'image).
Sortie : acc.json (aperçu navigateur) et AccArt.kt (utilisé par l'application)."""
import json, math, sys

def argb(hexcol, a=1.0):
    h = hexcol.lstrip('#'); r, g, b = int(h[0:2], 16), int(h[2:4], 16), int(h[4:6], 16)
    return (int(round(a * 255)) << 24) | (r << 16) | (g << 8) | b

class Path:
    def __init__(s, tx=0.0, ty=0.0, rot=0.0, sc=1.0):
        s.tx, s.ty, s.c, s.s, s.sc = tx, ty, math.cos(rot), math.sin(rot), sc
        s.cmd, s.ys = [], []
    def _p(s, x, y):
        X = (x * s.c - y * s.s) * s.sc + s.tx; Y = (x * s.s + y * s.c) * s.sc + s.ty
        s.ys.append(Y); return f"{X:.1f} {Y:.1f}"
    def M(s, x, y): s.cmd.append("M " + s._p(x, y)); return s
    def L(s, x, y): s.cmd.append("L " + s._p(x, y)); return s
    def Q(s, a, b, x, y): s.cmd.append("Q " + s._p(a, b) + " " + s._p(x, y)); return s
    def C(s, a, b, c, d, x, y): s.cmd.append("C " + s._p(a, b) + " " + s._p(c, d) + " " + s._p(x, y)); return s
    def Z(s): s.cmd.append("Z"); return s
    def d(s): return " ".join(s.cmd)
    def y0(s): return min(s.ys)
    def y1(s): return max(s.ys)

K = 0.5523
def ell(cx, cy, rx, ry, **tf):
    p = Path(**tf)
    p.M(cx + rx, cy).C(cx + rx, cy + K * ry, cx + K * rx, cy + ry, cx, cy + ry)
    p.C(cx - K * rx, cy + ry, cx - rx, cy + K * ry, cx - rx, cy)
    p.C(cx - rx, cy - K * ry, cx - K * rx, cy - ry, cx, cy - ry)
    p.C(cx + K * rx, cy - ry, cx + rx, cy - K * ry, cx + rx, cy).Z()
    return p
def poly(pts, close=True, **tf):
    p = Path(**tf); p.M(*pts[0])
    for q in pts[1:]: p.L(*q)
    if close: p.Z()
    return p
def star(cx, cy, r, r2, n=5, rot=-math.pi / 2, **tf):
    pts = []
    for i in range(2 * n):
        a = rot + i * math.pi / n; rr = r if i % 2 == 0 else r2
        pts.append((cx + math.cos(a) * rr, cy + math.sin(a) * rr))
    return poly(pts, **tf)
def sparkle(cx, cy, r, **tf):
    p = Path(**tf); k = 0.14 * r
    p.M(cx, cy - r).Q(cx + k, cy - k, cx + r, cy).Q(cx + k, cy + k, cx, cy + r)
    p.Q(cx - k, cy + k, cx - r, cy).Q(cx - k, cy - k, cx, cy - r).Z()
    return p

def layer(p, fill=None, fill2=None, stroke=None, sw=0.0, fa=1.0, f2a=1.0, sa=1.0):
    L = dict(d=p.d(), fill=argb(fill, fa) if fill else 0, fill2=argb(fill2, f2a) if fill2 else 0,
             gy0=round(p.y0(), 1), gy1=round(p.y1(), 1),
             stroke=argb(stroke, sa) if stroke else 0, sw=sw)
    return L

ART = {}
def art(id_, layers, bob=0.0): ART[id_] = dict(layers=layers, bob=bob)

# ---------------------------------------------------------------- TÊTE
def witch():
    tf = dict(tx=790, ty=294, rot=-0.10)
    ls = [layer(ell(0, 0, 108, 22, **tf), '#6a38b8', '#3a1670', '#22104a', 3)]
    c = Path(**tf).M(-64, -4).C(-56, -60, -6, -108, 38, -146).C(46, -100, 58, -46, 64, -4).Q(0, 10, -64, -4).Z()
    ls.append(layer(c, '#6c3bbd', '#3f1c80', '#24104d', 3))
    b = Path(**tf).M(-63, -12).Q(0, 6, 63, -12).L(59, -32).Q(0, -14, -59, -32).Z()
    ls.append(layer(b, '#ffe58a', '#e0a21c', '#8a5a10', 2))
    ls.append(layer(star(0, -20, 11, 5, **tf), '#fff3b0', None, '#a06a10', 2))
    for x, y, r in [(-22, -70, 7), (14, -96, 6), (-36, -42, 5), (30, -60, 4)]:
        ls.append(layer(sparkle(x, y, r, **tf), '#ffe9a8'))
    art('acc_witch', ls)
witch()

def halo():
    r = ell(792, 238, 82, 17)
    art('acc_halo', [layer(r, stroke='#ffd75a', sw=22, sa=0.14), layer(r, stroke='#ffd75a', sw=13, sa=0.30),
                     layer(r, stroke='#fff2b0', sw=6)], bob=5)
halo()

def flowercrown():
    pts = [(668, 352), (700, 322), (745, 300), (790, 292), (838, 297), (885, 312), (925, 338)]
    pal = [('#ff9ec7', '#c4457f', '#fff0a0'), ('#ffffff', '#c9b6d9', '#ffd24d'),
           ('#c9a8ff', '#7f55c9', '#fff0a0'), ('#ffb3a0', '#c8604d', '#fff0a0')]
    ls = []
    for i in range(len(pts) - 1):
        mx, my = (pts[i][0] + pts[i + 1][0]) / 2, (pts[i][1] + pts[i + 1][1]) / 2 + 9
        ls.append(layer(ell(mx, my, 13, 6, rot=0.5 if i % 2 else -0.5, tx=0, ty=0), '#78d68a', None, '#3f9a55', 1.5))
    for i, (x, y) in enumerate(pts):
        pet, edge, cen = pal[i % 4]; r = 19 if i % 2 == 0 else 16
        for k in range(5):
            a = k * 2 * math.pi / 5 - math.pi / 2
            ls.append(layer(ell(x + math.cos(a) * r * 0.62, y + math.sin(a) * r * 0.62, r * 0.5, r * 0.36, rot=a, tx=0, ty=0)
                            if False else _rot_ell(x + math.cos(a) * r * 0.62, y + math.sin(a) * r * 0.62, r * 0.5, r * 0.36, a),
                            pet, None, edge, 1.5))
        ls.append(layer(ell(x, y, r * 0.3, r * 0.3), cen, None, '#c8923a', 1.2))
    art('acc_flowercrown', ls)
def _rot_ell(cx, cy, rx, ry, rot):
    p = Path(tx=cx, ty=cy, rot=rot)
    p.M(rx, 0).C(rx, K * ry, K * rx, ry, 0, ry).C(-K * rx, ry, -rx, K * ry, -rx, 0)
    p.C(-rx, -K * ry, -K * rx, -ry, 0, -ry).C(K * rx, -ry, rx, -K * ry, rx, 0).Z()
    return p
flowercrown()

def party():
    tf = dict(tx=802, ty=292, rot=0.12)
    ls = []
    cone = poly([(-50, 0), (0, -124), (50, 0)], **tf)
    ls.append(layer(cone, '#ff8ad0', '#8b4dff', '#4a1f99', 3))
    w = lambda y: 50 * (1 + y / 124)
    for h in (-24, -54, -84):
        ls.append(layer(poly([(-w(h), h), (w(h), h), (w(h - 13), h - 13), (-w(h - 13), h - 13)], **tf), '#ffe27a', None, None, 0, fa=0.9))
    for x, y in [(-14, -14), (18, -40), (-8, -70), (10, -100)]:
        ls.append(layer(ell(x, y, 3.2, 3.2, **tf), '#ffffff', fa=0.85))
    ls.append(layer(ell(0, 3, 54, 10, **tf), '#ffd24d', '#e0a21c', '#8a5a10', 2))
    ls.append(layer(ell(0, -127, 13, 13, **tf), '#fff6c8', '#ffe27a', '#d9b24a', 2))
    art('acc_party', ls)
party()

def headband():
    base = Path().M(692, 334).Q(790, 262, 894, 322)
    hi = Path().M(696, 329).Q(790, 257, 890, 317)
    st = star(868, 304, 22, 9.5, rot=-math.pi / 2 + 0.2)
    art('acc_headband', [layer(base, stroke='#b83a7a', sw=18), layer(base, stroke='#ff8fcf', sw=12),
                         layer(hi, stroke='#ffffff', sw=3, sa=0.55),
                         layer(st, '#fff0a0', '#e8a822', '#a06a10', 2.5), layer(sparkle(818, 281, 9), '#fff3b0'),
                         layer(sparkle(742, 296, 7), '#fff3b0')])
headband()

# ---------------------------------------------------------------- VISAGE
LENS_L = (714, 476, 72, 62, -0.10)
LENS_R = (928, 433, 64, 60, -0.17)
def lens(c, **kw):
    cx, cy, rx, ry, rot = c
    return _rot_ell(cx, cy, rx, ry, rot)
def glasses():
    ls = []
    for c in (LENS_L, LENS_R):
        ls.append(layer(lens(c), '#bfe4ff', None, None, 0, fa=0.13))
    for c in (LENS_L, LENS_R):
        ls.append(layer(lens(c), None, None, '#e0a93a', 6))
    for c in (LENS_L, LENS_R):
        cx, cy = c[0], c[1]
        ls.append(layer(Path().M(cx - 44, cy - 24).Q(cx - 24, cy - 44, cx + 2, cy - 48), stroke='#ffffff', sw=4, sa=0.65))
    ls.append(layer(Path().M(783, 468).Q(826, 438, 866, 436), stroke='#e0a93a', sw=6))
    ls.append(layer(Path().M(643, 474).L(618, 462), stroke='#e0a93a', sw=5))
    ls.append(layer(Path().M(992, 426).L(1016, 414), stroke='#e0a93a', sw=5))
    art('acc_glasses', ls)
glasses()

def sunglasses():
    ls = []
    for c in (LENS_L, LENS_R):
        ls.append(layer(lens(c), '#3a2468', '#0b0618', '#14082c', 7, fa=0.93, f2a=0.95))
    for c in (LENS_L, LENS_R):
        cx, cy = c[0], c[1]
        ls.append(layer(poly([(cx - 46, cy - 20), (cx - 20, cy - 44), (cx - 4, cy - 40), (cx - 34, cy - 6)]), '#ffffff', fa=0.22))
    ls.append(layer(Path().M(783, 466).Q(826, 436, 866, 434), stroke='#14082c', sw=8))
    ls.append(layer(Path().M(643, 474).L(616, 460), stroke='#14082c', sw=6))
    ls.append(layer(Path().M(992, 426).L(1018, 412), stroke='#14082c', sw=6))
    art('acc_sunglasses', ls)
sunglasses()

def cheekstars():
    ls = []
    for x, y, r in [(676, 524, 16), (978, 474, 15)]:
        ls.append(layer(star(x, y, r, r * 0.45), '#ffb3e0', '#ff5fb0', '#d03d8d', 1.5))
    for x, y, r in [(652, 506, 7), (1000, 452, 7), (700, 548, 6), (958, 498, 6)]:
        ls.append(layer(sparkle(x, y, r), '#ffffff'))
    art('acc_cheekstars', ls)
cheekstars()

# ---------------------------------------------------------------- COU
def bez(p0, p1, p2, p3, t):
    u = 1 - t
    return (u**3 * p0[0] + 3 * u * u * t * p1[0] + 3 * u * t * t * p2[0] + t**3 * p3[0],
            u**3 * p0[1] + 3 * u * u * t * p1[1] + 3 * u * t * t * p2[1] + t**3 * p3[1])
def scarf():
    P0, P1, P2, P3 = (738, 572), (765, 630), (845, 630), (874, 566)
    band = Path().M(*P0).C(*P1, *P2, *P3)
    ls = [layer(band, stroke='#7a1830', sw=40), layer(band, stroke='#b8304f', sw=34)]
    for k in range(6):
        t0, t1 = 0.10 + k * 0.145, 0.10 + k * 0.145 + 0.06
        a, b = bez(P0, P1, P2, P3, t0), bez(P0, P1, P2, P3, t1)
        dx, dy = b[0] - a[0], b[1] - a[1]; n = math.hypot(dx, dy); nx, ny = -dy / n, dx / n
        h = 16
        ls.append(layer(poly([(a[0] + nx * h, a[1] + ny * h), (b[0] + nx * h, b[1] + ny * h),
                              (b[0] - nx * h, b[1] - ny * h), (a[0] - nx * h, a[1] - ny * h)]), '#ffe8ee', fa=0.9))
    ls.append(layer(band, stroke='#ffffff', sw=3, sa=0.25))
    tail = Path().M(746, 598).C(742, 628, 736, 660, 730, 692).L(764, 696).C(766, 662, 772, 632, 784, 606).Z()
    ls.append(layer(tail, '#c93b57', '#a02a45', '#6b1328', 2))
    xl = lambda y: 746 - 16 * (y - 598) / 96; xr = lambda y: 784 - 20 * (y - 606) / 90
    for y in (630, 662):
        ls.append(layer(poly([(xl(y), y), (xr(y), y), (xr(y + 11), y + 11), (xl(y + 11), y + 11)]), '#ffe8ee', fa=0.9))
    ls.append(layer(_rot_ell(852, 594, 24, 19, 0.35), '#9f2540', '#7a1830', '#4d0d1e', 2))
    art('acc_scarf', ls)
scarf()

def bowtie():
    tf = dict(tx=800, ty=597, rot=0.04)
    ls = []
    for s in (-1, 1):
        w = Path(**tf).M(s * 5, 0).L(s * 44, -23).Q(s * 55, 0, s * 44, 23).Z()
        ls.append(layer(w, '#8a4dff', '#4a1db0', '#2a0f66', 2.5))
        ls.append(layer(Path(**tf).M(s * 13, 0).L(s * 40, -12), stroke='#d2bcff', sw=1.8, sa=0.7))
        ls.append(layer(Path(**tf).M(s * 13, 0).L(s * 40, 12), stroke='#d2bcff', sw=1.8, sa=0.7))
    ls.append(layer(ell(0, 0, 10, 13, **tf), '#b08cff', '#7a4de0', '#2a0f66', 2))
    art('acc_bowtie', ls)
bowtie()

def pearls():
    P0, P1, P2 = (748, 586), (800, 646), (862, 584)
    q = lambda t: ((1 - t)**2 * P0[0] + 2 * (1 - t) * t * P1[0] + t * t * P2[0],
                   (1 - t)**2 * P0[1] + 2 * (1 - t) * t * P1[1] + t * t * P2[1])
    ls = [layer(Path().M(*P0).Q(*P1, *P2), stroke='#cdbab4', sw=2)]
    for i in range(11):
        x, y = q(i / 10)
        ls.append(layer(ell(x, y, 7.6, 7.6), '#fffaf4', '#eadfd6', '#c9b6ae', 1.4))
        ls.append(layer(ell(x - 2.6, y - 2.6, 2.4, 2.4), '#ffffff'))
    art('acc_pearls', ls)
pearls()

# ---------------------------------------------------------------- sortie
json.dump(ART, open(sys.argv[1] + '/acc.json', 'w'))
def lit(v):
    return f"0x{v & 0xFFFFFFFF:08X}" + ("L" if v >= 0x80000000 else "")
lines = ["package com.lumina.nyxie", "", "// Fichier généré par tools/make_acc.py : ne pas modifier à la main.", "",
         "class ArtLayer(", "    val d: String, val fill: Long = 0L, val fill2: Long = 0L,",
         "    val gy0: Float = 0f, val gy1: Float = 0f, val stroke: Long = 0L, val sw: Float = 0f,", ")", "",
         "class AccArt(val layers: List<ArtLayer>, val bob: Float = 0f)", "", "object AccArtData {",
         "    val art: Map<String, AccArt> = mapOf("]
for id_, a in ART.items():
    lines.append(f'        "{id_}" to AccArt(listOf(')
    for L in a['layers']:
        parts = [f'"{L["d"]}"']
        if L['fill']: parts.append(f"fill = {lit(L['fill'])}")
        if L['fill2']: parts.append(f"fill2 = {lit(L['fill2'])}")
        if L['fill2'] or L['fill']: parts.append(f"gy0 = {L['gy0']}f, gy1 = {L['gy1']}f")
        if L['stroke']: parts.append(f"stroke = {lit(L['stroke'])}, sw = {L['sw']}f")
        lines.append("            ArtLayer(" + ", ".join(parts) + "),")
    lines.append(f"        ), bob = {a['bob']}f),")
lines += ["    )", "}", ""]
open(sys.argv[1] + '/AccArt.kt', 'w').write("\n".join(lines))
print(len(ART), "accessoires,", sum(len(a['layers']) for a in ART.values()), "couches")
