"""Berceuse d'ambiance de Nyxie : boîte à musique + nappe douce, boucle parfaite (≈ 29 s)."""
import sys, wave
import numpy as np
from scipy.signal import butter, sosfilt
SR = 22050
BPM = 66
beat = 60 / BPM
bars = 8
total = bars * 4 * beat
N = int(total * SR)
rng = np.random.default_rng(11)
def hz(m): return 440 * 2 ** ((m - 69) / 12)
def render(): return np.zeros(N * 2)           # 2 boucles ; on garde la seconde (queues de réverbération incluses)
pad = render(); mel = render(); bass = render()
chords = [  # (basse, accord, gamme pour la mélodie)
    (45, (57, 60, 64), (69, 72, 74, 76, 79)),      # La mineur
    (41, (53, 57, 60), (65, 69, 72, 74, 77)),      # Fa
    (48, (55, 60, 64), (67, 72, 74, 76, 79)),      # Do
    (43, (55, 59, 62), (67, 71, 74, 76, 79)),      # Sol
]
def add(buf, start, sig):
    i = int(start * SR); j = min(len(buf), i + len(sig)); buf[i:j] += sig[:j - i]
def tone_pad(f, d):
    t = np.arange(int(d * SR)) / SR
    y = np.sin(2 * np.pi * f * t) + 0.35 * np.sin(2 * np.pi * 2 * f * t + 1.0) + 0.2 * np.sin(2 * np.pi * 0.5 * f * t)
    y *= (1 + 0.08 * np.sin(2 * np.pi * 0.2 * t + f))
    a = min(len(t), int(1.6 * SR)); e = np.ones(len(t)); e[:a] = np.linspace(0, 1, a) ** 1.5
    r = int(1.8 * SR); e[-r:] *= np.linspace(1, 0, r); return y * e
def bell(f, d=2.4):
    t = np.arange(int(d * SR)) / SR
    y = np.sin(2 * np.pi * f * t) * np.exp(-t * 2.2) + 0.45 * np.sin(2 * np.pi * 2.76 * f * t) * np.exp(-t * 6) \
        + 0.25 * np.sin(2 * np.pi * 5.4 * f * t) * np.exp(-t * 11)
    y[:int(0.004 * SR)] *= np.linspace(0, 1, int(0.004 * SR)); return y
for loop in range(2):
    off = loop * total
    for c, (b, ch, sc) in enumerate(chords):
        t0 = off + c * 2 * 4 * beat; dur = 2 * 4 * beat
        for m in ch: add(pad, t0, tone_pad(hz(m), dur + 1.5) * 0.16)
        for bar in range(2):
            add(bass, t0 + bar * 4 * beat, tone_pad(hz(b), 3.6 * beat) * 0.28)
        # mélodie : croches, une sur deux environ
        last = 2
        for k in range(16):
            if rng.random() < 0.52:
                step = int(rng.integers(-1, 2)); last = int(np.clip(last + step * (1 if rng.random() < .6 else 2), 0, 4))
                v = 0.55 + 0.35 * rng.random()
                add(mel, t0 + k * beat / 2, bell(hz(sc[last])) * 0.22 * v)
mix = pad + bass + mel
# délai/écho doux pour l'espace
d1, d2 = int(0.409 * SR), int(0.613 * SR)
out = mix.copy()
for i in range(len(mix)):
    pass
wet = np.zeros_like(mix)
for dl, g in ((d1, 0.38), (d2, 0.27), (int(0.97 * SR), 0.18)):
    wet[dl:] += mix[:-dl] * g
mix = mix + wet
sos = butter(2, 5200, 'low', fs=SR, output='sos'); mix = sosfilt(sos, mix)
loop = mix[N:N * 2]                                   # deuxième boucle = raccord parfait
loop = loop / np.max(np.abs(loop)) * 0.55
fade = int(0.02 * SR); loop[:fade] *= np.linspace(0, 1, fade); loop[-fade:] *= np.linspace(1, 0, fade)
w = wave.open(sys.argv[1], 'wb'); w.setnchannels(1); w.setsampwidth(2); w.setframerate(SR)
w.writeframes((loop * 32767).astype(np.int16).tobytes()); w.close()
print(round(len(loop) / SR, 1), 's')
