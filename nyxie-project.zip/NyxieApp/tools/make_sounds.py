"""Synthétise les petits bruitages de Nyxie (WAV 22,05 kHz mono) dans le dossier donné."""
import sys, wave
import numpy as np
from scipy.signal import butter, sosfilt

SR = 22050
rng = np.random.default_rng(3)
def T(d): return np.arange(int(SR * d)) / SR
def env(n, a=0.01, r=0.05):
    e = np.ones(n); na, nr = max(1, int(a * SR)), max(1, int(r * SR))
    e[:na] = np.linspace(0, 1, na); e[-nr:] = np.minimum(e[-nr:], np.linspace(1, 0, nr)); return e
def lp(x, f, o=2): return sosfilt(butter(o, f, 'low', fs=SR, output='sos'), x)
def hp(x, f, o=2): return sosfilt(butter(o, f, 'high', fs=SR, output='sos'), x)
def bp(x, a, b, o=2): return sosfilt(butter(o, [a, b], 'band', fs=SR, output='sos'), x)
def glide(f0, f1, d, vib=0.0, vf=6.0):
    t = T(d); f = np.linspace(f0, f1, len(t)) * (1 + vib * np.sin(2 * np.pi * vf * t))
    return np.cumsum(2 * np.pi * f / SR)
def voice(ph, formants=((1.0, 1.0),), nh=14):
    y = np.zeros_like(ph)
    for h in range(1, nh + 1): y += np.sin(h * ph) / h ** 1.1
    return y
def norm(x, peak=0.8): return x / (np.max(np.abs(x)) + 1e-9) * peak
def save(name, x):
    x = np.clip(x, -1, 1); w = wave.open(f'{sys.argv[1]}/{name}.wav', 'wb')
    w.setnchannels(1); w.setsampwidth(2); w.setframerate(SR); w.writeframes((x * 32767).astype(np.int16).tobytes()); w.close()

def meow(f0=620, f1=880, d=0.55, amp=1.0):
    n = int(SR * d); ph = np.concatenate([glide(f0, f1, d * 0.4, 0.015), glide(f1, f0 * 0.75, d * 0.6, 0.02)])[:n]
    ph = ph + 0.0; y = voice(ph, nh=18)
    t = T(d)[:n]; sweep = 700 + 1100 * np.sin(np.pi * np.minimum(t / d, 1))      # voyelle « mi-a-ou »
    out = np.zeros(n)
    for c in (0, 1):
        pass
    y1 = bp(y, 500, 1100) + 0.9 * bp(y, 1400, 2800) + 0.25 * y
    y = y1 * env(n, 0.03, 0.12) * (0.75 + 0.25 * np.sin(np.pi * t / d))
    return norm(y, 0.75 * amp)

def purr(d=2.6):
    t = T(d); n = len(t)
    pulse = (np.sin(2 * np.pi * 24 * t) > -0.2).astype(float); pulse = lp(pulse, 60, 2)
    saw = voice(2 * np.pi * np.cumsum(np.full(n, 62.0)) / SR, nh=10)
    y = lp(saw, 600) * (0.35 + 0.65 * pulse) + 0.5 * lp(rng.normal(size=n), 400) * (0.3 + 0.7 * pulse)
    return norm(y * env(n, 0.35, 0.5) * (1 + 0.15 * np.sin(2 * np.pi * 0.7 * t)), 0.7)

def munch():
    n = int(SR * 1.05); y = np.zeros(n)
    for k, st in enumerate((0.02, 0.27, 0.52, 0.77)):
        m = int(SR * 0.16); tt = np.arange(m) / SR
        crack = bp(rng.normal(size=m), 1500 + 300 * k, 5200) * np.exp(-tt * 38)
        thump = np.sin(2 * np.pi * (170 - 40 * tt / 0.16) * tt) * np.exp(-tt * 22) * 0.9
        i = int(st * SR); y[i:i + m] += (crack * 1.2 + thump)
    return norm(lp(y, 7000), 0.8)

def chirp():
    parts = []
    for f0, f1, d in ((700, 1000, 0.13), (900, 1250, 0.12), (1000, 1400, 0.17)):
        ph = glide(f0, f1, d, 0.02, 14); y = (np.sin(ph) + 0.3 * np.sin(2 * ph)) * env(len(ph), 0.01, 0.05)
        parts += [y, np.zeros(int(SR * 0.035))]
    return norm(np.concatenate(parts), 0.7)

def giggle():
    parts = []
    for i, f in enumerate((780, 960, 800, 1000, 840)):
        d = 0.09; ph = glide(f, f * 1.15, d); y = (np.sin(ph) + 0.4 * np.sin(2 * ph)) * env(len(ph), 0.008, 0.04) * (1 - 0.1 * i)
        parts += [y, np.zeros(int(SR * 0.045))]
    return norm(np.concatenate(parts), 0.7)

def splash():
    d = 1.0; n = int(SR * d); y = bp(rng.normal(size=n), 600, 4500) * np.exp(-T(d) * 3.2) * 0.5
    for st in (0.05, 0.2, 0.33, 0.5, 0.62):
        m = int(SR * 0.09); ph = glide(420, 1250, 0.09); b = np.sin(ph) * np.exp(-np.arange(m) / SR * 30)
        i = int(st * SR); y[i:i + m] += b[:m] * 0.8
    return norm(y * env(n, 0.005, 0.15), 0.75)

def brush():
    d = 0.9; n = int(SR * d); t = T(d)
    sw = (np.sin(2 * np.pi * 2.2 * t - 1.2) > 0) * np.abs(np.sin(2 * np.pi * 2.2 * t - 1.2))
    return norm(bp(rng.normal(size=n), 2500, 8000) * sw * env(n, 0.02, 0.1), 0.6)

def yawn():
    d = 1.5
    ph = np.concatenate([glide(420, 620, 0.55, 0.01), glide(620, 260, 0.95, 0.02)]); n = len(ph); t = np.arange(n) / SR
    y = bp(voice(ph, nh=12), 300, 1400) * np.sin(np.pi * np.minimum(t / d, 1)) ** 0.7
    br = hp(rng.normal(size=n), 2500) * 0.12 * np.sin(np.pi * np.minimum(t / d, 1))
    return norm((y + br) * env(n, 0.1, 0.25), 0.65)

def bell(f, d, a=1.0):
    t = T(d); return a * (np.sin(2 * np.pi * f * t) + 0.35 * np.sin(2 * np.pi * 2.01 * f * t)) * np.exp(-t * 7) * env(len(t), 0.003, 0.02)
def seq(notes, gap, tail=0.5):
    n = int(SR * (gap * len(notes) + tail)); y = np.zeros(n)
    for i, f in enumerate(notes):
        b = bell(f, tail); k = int(i * gap * SR); y[k:k + len(b)] += b[:n - k]
    return y

def sad():
    d = 0.7; ph = glide(700, 430, d, 0.03, 7); t = np.arange(len(ph)) / SR
    y = bp(voice(ph, nh=10), 500, 1800) * env(len(ph), 0.05, 0.25) * (0.6 + 0.4 * np.sin(np.pi * t / d))
    return norm(y, 0.6)

def shutter():
    n = int(SR * 0.28); y = np.zeros(n)
    for st, a in ((0.0, 1.0), (0.11, 0.7)):
        m = int(SR * 0.05); tt = np.arange(m) / SR
        c = (bp(rng.normal(size=m), 1800, 7000) * np.exp(-tt * 90) + 0.6 * np.sin(2 * np.pi * 900 * tt) * np.exp(-tt * 120)) * a
        i = int(st * SR); y[i:i + m] += c
    return norm(y, 0.7)

save('snd_shutter', shutter()); save('snd_purr', purr()); save('snd_meow', meow()); save('snd_meow2', meow(760, 1050, 0.4, 0.9))
save('snd_munch', munch()); save('snd_chirp', chirp()); save('snd_giggle', giggle())
save('snd_splash', splash()); save('snd_brush', brush()); save('snd_yawn', yawn()); save('snd_sad', sad())
save('snd_sparkle', norm(seq([1568, 1976, 2349, 3136], 0.09, 0.6), 0.6))
save('snd_coin', norm(seq([1319, 1760], 0.08, 0.35), 0.55))
save('snd_levelup', norm(seq([523, 659, 784, 1047, 1319], 0.1, 0.8), 0.65))
