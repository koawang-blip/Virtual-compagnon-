"""Génère les caches de peau (yeux, bouche) à partir de polygones précis.

Usage : python3 -I gen_patches.py scene.png out_dir
Écrit nyxie_lid_l.png, nyxie_lid_r.png, nyxie_mouth_cover.png et patches.json
"""
import json, sys, os
import numpy as np
from PIL import Image, ImageDraw, ImageFilter
from scipy import ndimage as ndi
from scipy.sparse import lil_matrix
from scipy.sparse.linalg import spsolve

scene_path, out_dir = sys.argv[1], sys.argv[2]
os.makedirs(out_dir, exist_ok=True)
im = Image.open(scene_path).convert('RGB')
W, H = im.size
A = np.asarray(im).astype(np.float32)
# Version sans paillettes pour lire la couleur de la peau autour
med = np.stack([ndi.median_filter(A[:, :, k], size=5) for k in range(3)], axis=2)

POLY = {
    'lid_l': [(647,492),(648,472),(656,457),(668,446),(682,436),(698,428),(716,423),(740,423),
              (760,430),(774,444),(783,462),(785,482),(780,496),(768,506),(748,514),(722,522),
              (700,525),(676,522),(658,512),(648,503)],
    'lid_r': [(872,440),(872,420),(880,402),(896,388),(918,382),(942,382),(956,389),(962,402),
              (972,408),(976,416),(976,426),(965,430),(962,440),(958,456),(952,468),(938,478),(916,480),(896,480),(880,474),(872,460)],
    'mouth_cover': [(770,510),(778,498),(794,490),(814,487),(834,484),(856,481),(876,478),(892,478),(900,488),
                    (896,506),(886,524),(868,540),(844,550),(816,550),(794,540),(778,526)],
}

def smooth_noise(shape, seed, sigma=1.1):
    rng = np.random.default_rng(seed)
    n = rng.normal(0, 1, shape)
    return ndi.gaussian_filter(n, sigma)

def build(name, pts, pad=12):
    xs = [p[0] for p in pts]; ys = [p[1] for p in pts]
    x0, y0 = int(min(xs)) - pad, int(min(ys)) - pad
    x1, y1 = int(max(xs)) + pad, int(max(ys)) + pad
    w, h = x1 - x0, y1 - y0
    # masque anti-crénelé (suréchantillonné)
    S = 4
    big = Image.new('L', (w * S, h * S), 0)
    ImageDraw.Draw(big).polygon([((px - x0) * S, (py - y0) * S) for px, py in pts], fill=255)
    soft = np.asarray(big.resize((w, h), Image.LANCZOS)).astype(np.float32) / 255.0
    hard = soft > 0.5
    # anneau de conditions aux limites : 1 à 3 px autour du masque
    ring = ndi.binary_dilation(hard, iterations=4) & ~ndi.binary_dilation(hard, iterations=2)
    ring_img = med[y0:y1, x0:x1]
    # inconnues = pixels du masque (+1 px de marge)
    unk = ndi.binary_dilation(hard, iterations=1)
    idx = -np.ones((h, w), dtype=np.int64)
    ys_u, xs_u = np.nonzero(unk)
    idx[ys_u, xs_u] = np.arange(len(ys_u))
    n = len(ys_u)
    # hors de la zone remplie, on garde la peau d'origine : le bord se fond sans liseré sombre
    out = A[y0:y1, x0:x1].copy()
    # Laplace : chaque inconnue = moyenne de ses 4 voisins ; voisins connus -> valeur de l'image lissée
    for ch in range(3):
        M = lil_matrix((n, n)); b = np.zeros(n)
        for k in range(n):
            y, x = ys_u[k], xs_u[k]
            M[k, k] = 4.0
            for dy, dx in ((1,0),(-1,0),(0,1),(0,-1)):
                yy, xx = y + dy, x + dx
                if 0 <= yy < h and 0 <= xx < w and idx[yy, xx] >= 0:
                    M[k, idx[yy, xx]] = -1.0
                else:
                    yy = min(max(yy, 0), h - 1); xx = min(max(xx, 0), w - 1)
                    b[k] += ring_img[yy, xx, ch]
        sol = spsolve(M.tocsr(), b)
        out[ys_u, xs_u, ch] = sol
    # grain : très léger, pour ne pas faire "plastique"
    g = smooth_noise((h, w), hash(name) % 1000) * 2.2
    out += g[:, :, None]
    out = np.clip(out, 0, 255)
    # on garde la peau d'origine hors du masque ; alpha = masque assoupli
    alpha = ndi.gaussian_filter(soft, 0.9)
    alpha = np.clip(alpha * 1.15, 0, 1)
    rgba = np.dstack([out, alpha * 255]).astype(np.uint8)
    Image.fromarray(rgba, 'RGBA').save(os.path.join(out_dir, f'nyxie_{name}.png'))
    return dict(name=name, x=x0, y=y0, w=w, h=h)

meta = [build(k, v) for k, v in POLY.items() if k == 'mouth_cover']
json.dump(meta, open(os.path.join(out_dir, 'patches.json'), 'w'), indent=1)
print(json.dumps(meta))
