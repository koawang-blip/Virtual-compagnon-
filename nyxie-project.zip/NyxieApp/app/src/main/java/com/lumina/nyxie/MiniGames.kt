package com.lumina.nyxie

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.sin
import kotlin.random.Random

// ---------------------------------------------------------------------------
// Jeu 1 : étoiles filantes
// ---------------------------------------------------------------------------

private data class FallingStar(val id: Int, val x: Float, val y: Float, val v: Float, val rare: Boolean)

private fun DrawScope.drawStarShape(c: Offset, r: Float, color: Color) {
    val p = Path()
    for (i in 0 until 10) {
        val rad = if (i % 2 == 0) r else r * 0.45f
        val a = -1.5708f + i * 0.62832f
        val x = c.x + cos(a) * rad
        val y = c.y + sin(a) * rad
        if (i == 0) p.moveTo(x, y) else p.lineTo(x, y)
    }
    p.close()
    drawPath(p, color)
}

@Composable
fun StarGame(accent: Color, onFinish: (Int) -> Unit, onQuit: () -> Unit) {
    val stars = remember { mutableStateListOf<FallingStar>() }
    var timeLeft by remember { mutableFloatStateOf(20f) }
    var score by remember { mutableIntStateOf(0) }
    var over by remember { mutableStateOf(false) }

    LaunchedEffect(Unit) {
        var last = 0L
        var spawn = 0f
        var nextId = 0
        while (timeLeft > 0f) {
            withFrameNanos { nanos ->
                if (last == 0L) last = nanos
                val dt = ((nanos - last) / 1_000_000_000f).coerceIn(0f, 0.05f)
                last = nanos
                timeLeft -= dt
                spawn -= dt
                if (spawn <= 0f) {
                    spawn = 0.35f + Random.nextFloat() * 0.35f
                    stars.add(
                        FallingStar(
                            nextId++, 0.06f + Random.nextFloat() * 0.88f, -0.05f,
                            0.28f + Random.nextFloat() * 0.30f, Random.nextInt(6) == 0,
                        ),
                    )
                }
                var i = 0
                while (i < stars.size) {
                    val s = stars[i]
                    val ny = s.y + s.v * dt
                    if (ny > 1.08f) {
                        stars.removeAt(i)
                    } else {
                        stars[i] = s.copy(y = ny)
                        i++
                    }
                }
            }
        }
        over = true
    }

    Box(
        Modifier
            .fillMaxSize()
            .background(Brush.verticalGradient(listOf(Color(0xFF0B0620), Color(0xFF2A1458))), RoundedCornerShape(16.dp)),
    ) {
        Canvas(
            Modifier
                .fillMaxSize()
                .pointerInput(Unit) {
                    detectTapGestures { off ->
                        if (over) return@detectTapGestures
                        val w = size.width.toFloat()
                        val h = size.height.toFloat()
                        var best = -1
                        var bestD = Float.MAX_VALUE
                        for (i in stars.indices) {
                            val s = stars[i]
                            val d = hypot(off.x - s.x * w, off.y - s.y * h)
                            if (d < bestD) {
                                bestD = d
                                best = i
                            }
                        }
                        if (best >= 0 && bestD < 64f) {
                            score += if (stars[best].rare) 3 else 1
                            stars.removeAt(best)
                        }
                    }
                },
        ) {
            for (s in stars) {
                val c = Offset(s.x * size.width, s.y * size.height)
                if (s.rare) drawStarShape(c, 30f, Color(0xFFFF6FD8)) else drawStarShape(c, 24f, Color(0xFFFFE27A))
            }
        }
        Row(
            Modifier
                .fillMaxWidth()
                .padding(12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
        ) {
            Text("⭐ $score", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold)
            Text("${timeLeft.coerceAtLeast(0f).toInt()} s", color = Color.White, fontSize = 18.sp)
            Text(
                "Quitter",
                color = Color(0xFFB9A8DD),
                fontSize = 14.sp,
                modifier = Modifier.clickable { onQuit() },
            )
        }
        if (over) {
            ResultOverlay(
                title = "Terminé !",
                text = "Tu as attrapé $score points d'étoiles.",
                accent = accent,
                onOk = { onFinish(score) },
            )
        }
    }
}

// ---------------------------------------------------------------------------
// Jeu 2 : mémoire lunaire
// ---------------------------------------------------------------------------

@Composable
fun MemoryGame(accent: Color, onFinish: (Int) -> Unit, onQuit: () -> Unit) {
    val symbols = remember { listOf("🌙", "⭐", "💜", "🍓", "🌸", "🔮") }
    val deck = remember { (symbols + symbols).shuffled() }
    val flipped = remember { mutableStateListOf<Int>() }
    val matched = remember { mutableStateListOf<Int>() }
    var moves by remember { mutableIntStateOf(0) }
    var lock by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()

    fun tap(i: Int) {
        if (lock || i in flipped || i in matched) return
        flipped.add(i)
        if (flipped.size == 2) {
            moves++
            val a = flipped[0]
            val b = flipped[1]
            if (deck[a] == deck[b]) {
                matched.add(a)
                matched.add(b)
                flipped.clear()
            } else {
                lock = true
                scope.launch {
                    delay(800)
                    flipped.clear()
                    lock = false
                }
            }
        }
    }

    Box(
        Modifier
            .fillMaxSize()
            .background(Brush.verticalGradient(listOf(Color(0xFF0B0620), Color(0xFF2A1458))), RoundedCornerShape(16.dp)),
    ) {
        Column(Modifier.fillMaxSize().padding(10.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("Coups : $moves", color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                Text(
                    "Quitter",
                    color = Color(0xFFB9A8DD),
                    fontSize = 14.sp,
                    modifier = Modifier.clickable { onQuit() },
                )
            }
            for (row in 0 until 3) {
                Row(
                    Modifier.fillMaxWidth().weight(1f),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    for (col in 0 until 4) {
                        val i = row * 4 + col
                        val up = i in flipped || i in matched
                        Box(
                            Modifier
                                .weight(1f)
                                .fillMaxSize()
                                .background(
                                    if (i in matched) Color(0x445BFFB0) else if (up) Color(0xFF3B2478) else Color(0xFF241250),
                                    RoundedCornerShape(12.dp),
                                )
                                .border(1.dp, accent.copy(alpha = 0.6f), RoundedCornerShape(12.dp))
                                .clickable { tap(i) },
                            contentAlignment = Alignment.Center,
                        ) {
                            Text(if (up) deck[i] else "✦", fontSize = 26.sp, color = Color.White)
                        }
                    }
                }
            }
        }
        if (matched.size == deck.size) {
            ResultOverlay(
                title = "Bravo !",
                text = "Toutes les paires trouvées en $moves coups.",
                accent = accent,
                onOk = { onFinish(moves) },
            )
        }
    }
}

@Composable
private fun ResultOverlay(title: String, text: String, accent: Color, onOk: () -> Unit) {
    Box(
        Modifier
            .fillMaxSize()
            .background(Color(0xCC000000), RoundedCornerShape(16.dp))
            .clickable(enabled = false) {},
        contentAlignment = Alignment.Center,
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text(title, color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.Bold)
            Text(text, color = Color(0xFFE6D8FF), fontSize = 15.sp, textAlign = TextAlign.Center)
            Box(
                Modifier
                    .background(accent, RoundedCornerShape(12.dp))
                    .clickable { onOk() }
                    .padding(horizontal = 22.dp, vertical = 10.dp),
            ) {
                Text("Récupérer ma récompense", color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 15.sp)
            }
        }
    }
}
