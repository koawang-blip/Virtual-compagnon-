package com.lumina.nyxie

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.BarChart
import androidx.compose.material.icons.filled.Bedtime
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.Brush
import androidx.compose.material.icons.filled.CardGiftcard
import androidx.compose.material.icons.filled.ChatBubble
import androidx.compose.material.icons.filled.ChatBubbleOutline
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Diamond
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Inventory2
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Mood
import androidx.compose.material.icons.filled.PhotoLibrary
import androidx.compose.material.icons.filled.Restaurant
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.SportsEsports
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.TouchApp
import androidx.compose.material.icons.filled.WaterDrop
import androidx.compose.material.icons.filled.WbSunny
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

// ---------------------------------------------------------------------------
// Palette et petits composants
// ---------------------------------------------------------------------------

object Pal {
    val panel = Color(0xCC170B30)
    val panelSolid = Color(0xF2170B30)
    val border = Color(0x669B7BFF)
    val text = Color(0xFFF1E9FF)
    val dim = Color(0xFFB9A8DD)
    val gold = Color(0xFFFFC94D)
    val orange = Color(0xFFFFB23F)
    val blue = Color(0xFF4DA3FF)
    val red = Color(0xFFFF5C7A)
    val pink = Color(0xFFE056FF)
    val icon = Color(0xFFD7B8FF)
}

fun accentFor(theme: String): Color = when (theme) {
    "theme_rose" -> Color(0xFFFF6FAE)
    "theme_aqua" -> Color(0xFF35D0C8)
    "theme_gold" -> Color(0xFFE0A526)
    "theme_mint" -> Color(0xFF3DCB86)
    "theme_ruby" -> Color(0xFFE0415A)
    else -> Color(0xFF9B5CFF)
}

private val STYLE_REGION = Rect(-420f, 90f, 1252f, 851f)
private val THUMB_REGION = Rect(500f, 240f, 1180f, 700f)

@Composable
fun Txt(
    text: String,
    size: TextUnit = 13.sp,
    color: Color = Pal.text,
    weight: FontWeight = FontWeight.Normal,
    modifier: Modifier = Modifier,
    align: TextAlign? = null,
    maxLines: Int = Int.MAX_VALUE,
) {
    Text(
        text = text, modifier = modifier, color = color, fontSize = size, fontWeight = weight,
        textAlign = align, maxLines = maxLines, overflow = TextOverflow.Ellipsis,
    )
}

@Composable
fun Panel(modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) {
    Column(
        modifier = modifier
            .clip(RoundedCornerShape(18.dp))
            .background(Pal.panel)
            .border(1.dp, Pal.border, RoundedCornerShape(18.dp))
            .padding(10.dp),
        content = content,
    )
}

@Composable
fun Bar(value: Float, color: Color, modifier: Modifier = Modifier) {
    Box(
        modifier
            .fillMaxWidth()
            .height(8.dp)
            .clip(RoundedCornerShape(4.dp))
            .background(Color(0x33FFFFFF)),
    ) {
        Box(
            Modifier
                .fillMaxHeight()
                .fillMaxWidth(value.coerceIn(0f, 1f))
                .background(color, RoundedCornerShape(4.dp)),
        )
    }
}

@Composable
fun StatRow(icon: ImageVector, label: String, value: Float, color: Color) {
    Row(Modifier.fillMaxWidth().padding(vertical = 3.dp), verticalAlignment = Alignment.CenterVertically) {
        Icon(icon, null, tint = color, modifier = Modifier.size(18.dp))
        Txt(label, 12.sp, modifier = Modifier.width(62.dp).padding(start = 6.dp))
        Bar(value, color, Modifier.weight(1f))
    }
}

@Composable
fun PillButton(text: String, accent: Color, modifier: Modifier = Modifier, enabled: Boolean = true, onClick: () -> Unit) {
    Box(
        modifier
            .clip(RoundedCornerShape(12.dp))
            .background(if (enabled) accent else Color(0x33FFFFFF))
            .clickable(enabled = enabled, onClick = onClick)
            .padding(horizontal = 14.dp, vertical = 8.dp),
        contentAlignment = Alignment.Center,
    ) {
        Txt(text, 13.sp, Color.White, FontWeight.SemiBold, align = TextAlign.Center)
    }
}

fun Screen.icon(): ImageVector = when (this) {
    Screen.HOME -> Icons.Filled.Home
    Screen.CHAT -> Icons.Filled.ChatBubbleOutline
    Screen.CARE -> Icons.Filled.FavoriteBorder
    Screen.GAMES -> Icons.Filled.SportsEsports
    Screen.STYLE -> Icons.Filled.AutoAwesome
    Screen.GALLERY -> Icons.Filled.PhotoLibrary
    Screen.BAG -> Icons.Filled.Inventory2
    Screen.EVOLUTION -> Icons.Filled.BarChart
    Screen.SETTINGS -> Icons.Filled.Settings
}

// ---------------------------------------------------------------------------
// Racine
// ---------------------------------------------------------------------------

@Composable
fun NyxieApp(vm: GameViewModel, onMic: () -> Unit) {
    val s = vm.state
    val accent = accentFor(s.theme)
    var showFood by remember { mutableStateOf(false) }
    var showActivities by remember { mutableStateOf(false) }
    val onHome = vm.screen == Screen.HOME
    val onStyle = vm.screen == Screen.STYLE
    val tapHandler: (() -> Unit)? = if (onHome || onStyle) {
        { vm.tapNyxie() }
    } else {
        null
    }

    Box(Modifier.fillMaxSize().background(Color.Black)) {
        NyxieScene(
            state = s,
            reaction = vm.reaction,
            modifier = Modifier.fillMaxSize(),
            region = if (onStyle) STYLE_REGION else null,
            onTapNyxie = tapHandler,
        )
        if (!onHome && !onStyle) {
            Box(Modifier.fillMaxSize().background(Color(0x99090414)))
        }
        Column(
            Modifier
                .fillMaxSize()
                .windowInsetsPadding(WindowInsets.safeDrawing)
                .padding(8.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp),
        ) {
            TopBar(vm, accent)
            Row(
                Modifier.weight(1f).fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                NavRail(vm.screen, accent, Modifier.width(132.dp).fillMaxHeight()) { vm.screen = it }
                Box(Modifier.weight(1f).fillMaxHeight()) {
                    when (vm.screen) {
                        Screen.HOME -> HomeCenter(vm, accent, { showFood = true }, { showActivities = true }, onMic)
                        Screen.CHAT -> ChatScreen(vm, accent, onMic)
                        Screen.CARE -> CareScreen(vm, accent) { showFood = true }
                        Screen.GAMES -> GamesScreen(vm, accent)
                        Screen.STYLE -> StyleScreen(vm, accent)
                        Screen.GALLERY -> GalleryScreen(vm)
                        Screen.BAG -> BagScreen(vm, accent)
                        Screen.EVOLUTION -> EvolutionScreen(vm, accent)
                        Screen.SETTINGS -> SettingsScreen(vm, accent)
                    }
                }
                if (onHome) {
                    RightPanel(vm, accent, Modifier.width(212.dp).fillMaxHeight())
                }
            }
        }
        val toast = vm.toast
        if (toast != null) {
            Box(
                Modifier
                    .align(Alignment.TopCenter)
                    .windowInsetsPadding(WindowInsets.safeDrawing)
                    .padding(top = 64.dp)
                    .clip(RoundedCornerShape(20.dp))
                    .background(Pal.panelSolid)
                    .border(1.dp, accent, RoundedCornerShape(20.dp))
                    .padding(horizontal = 16.dp, vertical = 10.dp),
            ) {
                Txt(toast, 14.sp, weight = FontWeight.Medium)
            }
        }
        if (showFood) FoodDialog(vm) { showFood = false }
        if (showActivities) ActivityDialog(vm, accent) { showActivities = false }
    }
}

// ---------------------------------------------------------------------------
// Barre du haut et navigation
// ---------------------------------------------------------------------------

private val timeFmt = SimpleDateFormat("HH:mm", Locale.FRANCE)
private val dateFmt = SimpleDateFormat("EEE d MMM", Locale.FRANCE)

@Composable
fun TopBar(vm: GameViewModel, accent: Color) {
    val s = vm.state
    Row(
        Modifier.fillMaxWidth().height(52.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Row(
            Modifier
                .fillMaxHeight()
                .clip(RoundedCornerShape(16.dp))
                .background(Pal.panel)
                .border(1.dp, Pal.border, RoundedCornerShape(16.dp))
                .padding(horizontal = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            NyxieAvatar(Modifier.size(38.dp).clip(CircleShape).border(1.5.dp, accent, CircleShape))
            Column(Modifier.padding(start = 8.dp)) {
                Txt("${s.name} ♥", 17.sp, weight = FontWeight.Bold, maxLines = 1)
                Txt("Toujours à tes côtés", 10.sp, Pal.dim, maxLines = 1)
            }
        }
        Row(
            Modifier
                .weight(1f)
                .fillMaxHeight()
                .clip(RoundedCornerShape(16.dp))
                .background(Pal.panel)
                .border(1.dp, Pal.border, RoundedCornerShape(16.dp))
                .padding(horizontal = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Icon(Icons.Filled.Bedtime, null, tint = Pal.icon, modifier = Modifier.size(22.dp))
            Column(Modifier.padding(start = 8.dp).weight(1f)) {
                Row(Modifier.fillMaxWidth()) {
                    Txt("Niveau ${s.level}", 13.sp, weight = FontWeight.Medium)
                    Spacer(Modifier.weight(1f))
                    Txt("${s.xp} / ${xpNeeded(s.level)}", 11.sp, Pal.dim)
                }
                Spacer(Modifier.height(3.dp))
                Bar(s.xp.toFloat() / xpNeeded(s.level), accent)
            }
        }
        CurrencyChip(s.coins.toString(), true) { vm.screen = Screen.BAG }
        CurrencyChip(s.gems.toString(), false) { vm.screen = Screen.BAG }
        Column(
            Modifier
                .fillMaxHeight()
                .clip(RoundedCornerShape(16.dp))
                .background(Pal.panel)
                .border(1.dp, Pal.border, RoundedCornerShape(16.dp))
                .padding(horizontal = 12.dp),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Txt(timeFmt.format(Date(vm.now)), 16.sp, weight = FontWeight.Bold)
            Txt(dateFmt.format(Date(vm.now)), 10.sp, Pal.dim)
        }
    }
}

@Composable
private fun CurrencyChip(value: String, coin: Boolean, onPlus: () -> Unit) {
    Row(
        Modifier
            .fillMaxHeight()
            .clip(RoundedCornerShape(16.dp))
            .background(Pal.panel)
            .border(1.dp, Pal.border, RoundedCornerShape(16.dp))
            .padding(start = 10.dp, end = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        if (coin) {
            Box(Modifier.size(18.dp).background(Pal.gold, CircleShape))
        } else {
            Icon(Icons.Filled.Diamond, null, tint = Pal.pink, modifier = Modifier.size(20.dp))
        }
        Txt(value, 15.sp, weight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 6.dp))
        Box(
            Modifier
                .size(24.dp)
                .clip(RoundedCornerShape(7.dp))
                .background(Color(0x33FFFFFF))
                .clickable(onClick = onPlus),
            contentAlignment = Alignment.Center,
        ) {
            Icon(Icons.Filled.Add, null, tint = Pal.text, modifier = Modifier.size(16.dp))
        }
    }
}

@Composable
fun NavRail(current: Screen, accent: Color, modifier: Modifier, onSelect: (Screen) -> Unit) {
    Column(
        modifier
            .clip(RoundedCornerShape(18.dp))
            .background(Pal.panel)
            .border(1.dp, Pal.border, RoundedCornerShape(18.dp))
            .verticalScroll(rememberScrollState())
            .padding(6.dp),
        verticalArrangement = Arrangement.spacedBy(3.dp),
    ) {
        for (sc in Screen.values()) {
            val sel = sc == current
            Row(
                Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(12.dp))
                    .background(if (sel) accent.copy(alpha = 0.35f) else Color.Transparent)
                    .border(if (sel) 1.dp else 0.dp, if (sel) accent else Color.Transparent, RoundedCornerShape(12.dp))
                    .clickable { onSelect(sc) }
                    .padding(horizontal = 8.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Icon(sc.icon(), null, tint = if (sel) Color.White else Pal.icon, modifier = Modifier.size(18.dp))
                Txt(
                    sc.label, 11.sp, if (sel) Color.White else Pal.text,
                    if (sel) FontWeight.SemiBold else FontWeight.Normal,
                    Modifier.padding(start = 7.dp), maxLines = 1,
                )
            }
        }
    }
}

// ---------------------------------------------------------------------------
// Accueil
// ---------------------------------------------------------------------------

@Composable
fun HomeCenter(vm: GameViewModel, accent: Color, onFood: () -> Unit, onActivity: () -> Unit, onMic: () -> Unit) {
    val s = vm.state
    Box(Modifier.fillMaxSize()) {
        SpeechBubble(vm, accent, Modifier.align(Alignment.TopStart).widthIn(max = 250.dp))
        Column(Modifier.align(Alignment.BottomCenter), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                ActionButton(Icons.Filled.Restaurant, "Nourrir", accent, vm.reaction == Reaction.EAT, Modifier.weight(1f), onClick = onFood)
                ActionButton(Icons.Filled.TouchApp, "Caresser", accent, vm.reaction == Reaction.PET, Modifier.weight(1f)) { vm.pet() }
                ActionButton(Icons.Filled.SportsEsports, "Jouer", accent, vm.reaction == Reaction.PLAY, Modifier.weight(1f)) { vm.play() }
                ActionButton(Icons.Filled.ChatBubble, "Parler", accent, vm.reaction == Reaction.TALK, Modifier.weight(1f)) { vm.talk() }
                ActionButton(
                    Icons.Filled.Star, "Activité", accent, s.activityId != null, Modifier.weight(1f),
                    sub = if (s.activityId != null) "En cours" else null, onClick = onActivity,
                )
                ActionButton(
                    Icons.Filled.CardGiftcard, "Cadeau", accent, vm.reaction == Reaction.GIFT, Modifier.weight(1f),
                    badge = vm.giftReady(),
                ) { vm.claimGift() }
            }
            ChatInput(s.name, accent, { vm.send(it) }, onMic)
        }
    }
}

@Composable
fun SpeechBubble(vm: GameViewModel, accent: Color, modifier: Modifier) {
    var shown by remember { mutableStateOf("") }
    val text = vm.speech
    LaunchedEffect(text) {
        if (text != null) shown = text
    }
    AnimatedVisibility(
        visible = text != null,
        modifier = modifier,
        enter = fadeIn() + scaleIn(initialScale = 0.92f),
        exit = fadeOut(),
    ) {
        Column(
            Modifier
                .clip(RoundedCornerShape(18.dp))
                .background(Pal.panelSolid)
                .border(1.5.dp, accent, RoundedCornerShape(18.dp))
                .padding(horizontal = 14.dp, vertical = 10.dp),
        ) {
            Txt("${vm.state.name} ♥", 14.sp, accent, FontWeight.Bold)
            Txt(shown, 14.sp)
        }
    }
}

@Composable
fun ActionButton(
    icon: ImageVector,
    label: String,
    accent: Color,
    highlighted: Boolean,
    modifier: Modifier,
    sub: String? = null,
    badge: Boolean = false,
    onClick: () -> Unit,
) {
    val shape = RoundedCornerShape(16.dp)
    Box(
        modifier
            .height(62.dp)
            .clip(shape)
            .background(if (highlighted) accent.copy(alpha = 0.40f) else Pal.panel)
            .border(if (highlighted) 2.dp else 1.dp, if (highlighted) Color(0xFFFF7AC8) else Pal.border, shape)
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Icon(icon, null, tint = Pal.icon, modifier = Modifier.size(24.dp))
            Txt(label, 12.sp, maxLines = 1)
            if (sub != null) Txt(sub, 9.sp, Pal.dim, maxLines = 1)
        }
        if (badge) {
            Box(
                Modifier
                    .align(Alignment.TopEnd)
                    .padding(7.dp)
                    .size(10.dp)
                    .background(Pal.red, CircleShape),
            )
        }
    }
}

@Composable
fun ChatInput(name: String, accent: Color, onSend: (String) -> Unit, onMic: () -> Unit) {
    var text by remember { mutableStateOf("") }
    fun submit() {
        if (text.isNotBlank()) {
            onSend(text)
            text = ""
        }
    }
    Row(
        Modifier
            .fillMaxWidth()
            .height(46.dp)
            .clip(RoundedCornerShape(23.dp))
            .background(Pal.panel)
            .border(1.dp, Pal.border, RoundedCornerShape(23.dp))
            .padding(horizontal = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Icon(Icons.Filled.AutoAwesome, null, tint = Pal.icon, modifier = Modifier.size(22.dp))
        BasicTextField(
            value = text,
            onValueChange = { text = it },
            singleLine = true,
            textStyle = TextStyle(color = Pal.text, fontSize = 14.sp),
            cursorBrush = SolidColor(accent),
            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
            keyboardActions = KeyboardActions(onSend = { submit() }),
            modifier = Modifier.weight(1f).padding(horizontal = 10.dp),
            decorationBox = { inner ->
                Box(contentAlignment = Alignment.CenterStart) {
                    if (text.isEmpty()) Txt("Écris un message à $name…", 14.sp, Pal.dim)
                    inner()
                }
            },
        )
        Box(
            Modifier
                .size(34.dp)
                .clip(RoundedCornerShape(12.dp))
                .background(accent)
                .clickable { submit() },
            contentAlignment = Alignment.Center,
        ) {
            Icon(Icons.AutoMirrored.Filled.Send, null, tint = Color.White, modifier = Modifier.size(18.dp))
        }
        Spacer(Modifier.width(6.dp))
        Box(
            Modifier
                .size(34.dp)
                .clip(CircleShape)
                .background(Color(0x33FFFFFF))
                .clickable(onClick = onMic),
            contentAlignment = Alignment.Center,
        ) {
            Icon(Icons.Filled.Mic, null, tint = Pal.text, modifier = Modifier.size(18.dp))
        }
    }
}

@Composable
fun RightPanel(vm: GameViewModel, accent: Color, modifier: Modifier) {
    val s = vm.state
    Column(modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Panel(Modifier.fillMaxWidth()) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Filled.Mood, null, tint = Pal.icon, modifier = Modifier.size(20.dp))
                Txt("Humeur", 13.sp, weight = FontWeight.SemiBold, modifier = Modifier.padding(start = 6.dp))
                Spacer(Modifier.weight(1f))
                Txt(s.moodLabel, 12.sp, Pal.dim)
            }
            Spacer(Modifier.height(4.dp))
            Bar(s.mood, Pal.pink)
            Spacer(Modifier.height(4.dp))
            StatRow(Icons.Filled.Restaurant, "Faim", s.hunger, Pal.orange)
            StatRow(Icons.Filled.Bolt, "Énergie", s.energy, Pal.blue)
            StatRow(Icons.Filled.Favorite, "Affection", s.affection, Pal.red)
        }
        Panel(Modifier.fillMaxWidth()) {
            val a = s.activityId?.let { Catalog.activityById[it] }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Filled.Bedtime, null, tint = Pal.icon, modifier = Modifier.size(20.dp))
                Txt("Activité actuelle", 13.sp, weight = FontWeight.SemiBold, modifier = Modifier.padding(start = 6.dp))
            }
            Spacer(Modifier.height(4.dp))
            if (s.sleeping) {
                Txt("${s.name} dort… zzz", 12.sp, accent)
                Spacer(Modifier.height(6.dp))
                PillButton("Réveiller", accent) { vm.wake() }
            } else if (a != null) {
                val total = a.durationSec * 1000f
                val progress = ((vm.now - s.activityStart) / total).coerceIn(0f, 1f)
                val left = ((total - (vm.now - s.activityStart)) / 1000f).toInt().coerceAtLeast(0)
                Txt("${a.glyph} ${a.name}", 12.sp, accent)
                Spacer(Modifier.height(4.dp))
                Bar(progress, accent)
                Txt("Encore $left s", 11.sp, Pal.dim, modifier = Modifier.padding(top = 3.dp))
                Spacer(Modifier.height(6.dp))
                PillButton("Terminer", accent) { vm.finishActivity(true) }
            } else {
                Txt("Profite de ta présence", 12.sp, accent)
                Spacer(Modifier.height(4.dp))
                Bar(0f, accent)
            }
        }
        Panel(Modifier.fillMaxWidth()) {
            Txt("Dernières interactions", 13.sp, weight = FontWeight.SemiBold)
            Spacer(Modifier.height(4.dp))
            if (s.interactions.isEmpty()) {
                Txt("Rien pour l'instant. Caresse-la !", 12.sp, Pal.dim)
            }
            for (inter in s.interactions.take(4)) {
                Row(Modifier.fillMaxWidth().padding(vertical = 3.dp)) {
                    Txt(interactionText(inter.kind), 11.sp, modifier = Modifier.weight(1f), maxLines = 1)
                    Txt(ago(vm.now, inter.at), 10.sp, Pal.dim, modifier = Modifier.padding(start = 4.dp), maxLines = 1)
                }
            }
        }
    }
}

// ---------------------------------------------------------------------------
// Boîtes de dialogue
// ---------------------------------------------------------------------------

@Composable
fun FoodDialog(vm: GameViewModel, onDismiss: () -> Unit) {
    val s = vm.state
    val foods = Catalog.items.filter {
        (it.kind == ItemKind.FOOD || it.kind == ItemKind.TONIC) && (s.inventory[it.id] ?: 0) > 0
    }
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = Color(0xFF1A0F36),
        title = { Txt("Nourrir ${s.name}", 18.sp, weight = FontWeight.Bold) },
        text = {
            if (foods.isEmpty()) {
                Txt("Ton sac est vide. Achète de la nourriture dans l'inventaire.", 14.sp, Pal.dim)
            } else {
                Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    for (item in foods) {
                        Row(
                            Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(12.dp))
                                .background(Color(0x22FFFFFF))
                                .clickable {
                                    vm.feed(item.id)
                                    onDismiss()
                                }
                                .padding(10.dp),
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            Txt(item.glyph, 22.sp)
                            Column(Modifier.weight(1f).padding(start = 10.dp)) {
                                Txt(item.name, 14.sp, weight = FontWeight.Medium)
                                Txt(item.desc, 11.sp, Pal.dim)
                            }
                            Txt("x${s.inventory[item.id] ?: 0}", 13.sp, Pal.gold)
                        }
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = {
                vm.screen = Screen.BAG
                onDismiss()
            }) { Text("Boutique", color = Pal.icon) }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Fermer", color = Pal.dim) } },
    )
}

@Composable
fun ActivityDialog(vm: GameViewModel, accent: Color, onDismiss: () -> Unit) {
    val s = vm.state
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = Color(0xFF1A0F36),
        title = { Txt("Choisir une activité", 18.sp, weight = FontWeight.Bold) },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                if (s.activityId != null) {
                    Txt("Une activité est déjà en cours.", 13.sp, Pal.dim)
                    PillButton("Terminer maintenant", accent) {
                        vm.finishActivity(true)
                        onDismiss()
                    }
                }
                for (a in Catalog.activities) {
                    Row(
                        Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(12.dp))
                            .background(Color(0x22FFFFFF))
                            .clickable {
                                vm.startActivity(a.id)
                                onDismiss()
                            }
                            .padding(10.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Txt(a.glyph, 22.sp)
                        Column(Modifier.weight(1f).padding(start = 10.dp)) {
                            Txt(a.name, 14.sp, weight = FontWeight.Medium)
                            Txt("${a.durationSec} s  •  +${a.xp} XP  •  +${a.coins} pièces", 11.sp, Pal.dim)
                        }
                    }
                }
            }
        },
        confirmButton = {},
        dismissButton = { TextButton(onClick = onDismiss) { Text("Fermer", color = Pal.dim) } },
    )
}

// ---------------------------------------------------------------------------
// Discussion
// ---------------------------------------------------------------------------

@Composable
fun ChatScreen(vm: GameViewModel, accent: Color, onMic: () -> Unit) {
    val listState = rememberLazyListState()
    LaunchedEffect(vm.chat.size) {
        if (vm.chat.isNotEmpty()) listState.animateScrollToItem(vm.chat.size - 1)
    }
    Panel(Modifier.fillMaxSize()) {
        Txt("Discussion avec ${vm.state.name}", 16.sp, weight = FontWeight.Bold)
        Spacer(Modifier.height(6.dp))
        LazyColumn(
            Modifier.weight(1f).fillMaxWidth(),
            state = listState,
            verticalArrangement = Arrangement.spacedBy(6.dp),
        ) {
            if (vm.chat.isEmpty()) {
                item { Txt("Écris-lui un petit mot, elle répondra avec plaisir.", 13.sp, Pal.dim) }
            }
            items(vm.chat) { m ->
                Row(
                    Modifier.fillMaxWidth(),
                    horizontalArrangement = if (m.fromUser) Arrangement.End else Arrangement.Start,
                ) {
                    Box(
                        Modifier
                            .widthIn(max = 360.dp)
                            .clip(RoundedCornerShape(14.dp))
                            .background(if (m.fromUser) accent.copy(alpha = 0.55f) else Color(0x33FFFFFF))
                            .padding(horizontal = 12.dp, vertical = 8.dp),
                    ) {
                        Txt(m.text, 14.sp)
                    }
                }
            }
        }
        Spacer(Modifier.height(6.dp))
        ChatInput(vm.state.name, accent, { vm.send(it) }, onMic)
    }
}

// ---------------------------------------------------------------------------
// Soins
// ---------------------------------------------------------------------------

@Composable
fun CareScreen(vm: GameViewModel, accent: Color, onFood: () -> Unit) {
    val s = vm.state
    Panel(Modifier.fillMaxSize()) {
        Txt("Prendre soin de ${s.name}", 16.sp, weight = FontWeight.Bold)
        Spacer(Modifier.height(8.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            CareCard(Icons.Filled.Restaurant, "Nourrir", "Un bon repas.", accent, Modifier.weight(1f), onFood)
            CareCard(Icons.Filled.WaterDrop, "Bain de lune", "Affection +", accent, Modifier.weight(1f)) { vm.careBath() }
            CareCard(Icons.Filled.Brush, "Brossage", "Plumes brillantes.", accent, Modifier.weight(1f)) { vm.careBrush() }
            CareCard(
                if (s.sleeping) Icons.Filled.WbSunny else Icons.Filled.Bedtime,
                if (s.sleeping) "Réveiller" else "Dormir",
                if (s.sleeping) "Elle dort…" else "Regagne de l'énergie.",
                accent, Modifier.weight(1f),
            ) { vm.toggleSleep() }
        }
        Spacer(Modifier.height(12.dp))
        StatRow(Icons.Filled.Mood, "Humeur", s.mood, Pal.pink)
        StatRow(Icons.Filled.Restaurant, "Faim", s.hunger, Pal.orange)
        StatRow(Icons.Filled.Bolt, "Énergie", s.energy, Pal.blue)
        StatRow(Icons.Filled.Favorite, "Affection", s.affection, Pal.red)
        Spacer(Modifier.height(6.dp))
        Txt("Humeur actuelle : ${s.moodLabel}", 12.sp, Pal.dim)
    }
}

@Composable
private fun CareCard(icon: ImageVector, title: String, sub: String, accent: Color, modifier: Modifier, onClick: () -> Unit) {
    Column(
        modifier
            .clip(RoundedCornerShape(16.dp))
            .background(Color(0x22FFFFFF))
            .border(1.dp, Pal.border, RoundedCornerShape(16.dp))
            .clickable(onClick = onClick)
            .padding(10.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Icon(icon, null, tint = accent, modifier = Modifier.size(30.dp))
        Spacer(Modifier.height(4.dp))
        Txt(title, 13.sp, weight = FontWeight.SemiBold, align = TextAlign.Center)
        Txt(sub, 10.sp, Pal.dim, align = TextAlign.Center)
    }
}

// ---------------------------------------------------------------------------
// Jeux
// ---------------------------------------------------------------------------

@Composable
fun GamesScreen(vm: GameViewModel, accent: Color) {
    var game by remember { mutableStateOf<String?>(null) }
    val s = vm.state
    when (game) {
        "stars" -> Box(Modifier.fillMaxSize()) {
            StarGame(accent, onFinish = { score ->
                vm.finishStars(score)
                game = null
            }, onQuit = { game = null })
        }
        "memory" -> Box(Modifier.fillMaxSize()) {
            MemoryGame(accent, onFinish = { moves ->
                vm.finishMemory(moves)
                game = null
            }, onQuit = { game = null })
        }
        else -> Panel(Modifier.fillMaxSize()) {
            Txt("Jeux et petites aventures", 16.sp, weight = FontWeight.Bold)
            Txt("Chaque partie coûte un peu d'énergie et rapporte des pièces et de l'expérience.", 12.sp, Pal.dim)
            Spacer(Modifier.height(10.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                GameCard(
                    "⭐", "Étoiles filantes", "Touche les étoiles qui tombent pendant 20 secondes.",
                    "Record : ${s.bestStars}", accent, Modifier.weight(1f),
                ) {
                    if (s.sleeping) vm.showToast("${s.name} dort.")
                    else if (s.energy < 0.15f) vm.showToast("${s.name} est trop fatiguée pour jouer.")
                    else game = "stars"
                }
                GameCard(
                    "🔮", "Mémoire lunaire", "Retrouve toutes les paires avec le moins de coups.",
                    if (s.bestMemory == 0) "Pas encore de record" else "Record : ${s.bestMemory} coups", accent,
                    Modifier.weight(1f),
                ) {
                    if (s.sleeping) vm.showToast("${s.name} dort.")
                    else if (s.energy < 0.15f) vm.showToast("${s.name} est trop fatiguée pour jouer.")
                    else game = "memory"
                }
            }
        }
    }
}

@Composable
private fun GameCard(glyph: String, title: String, desc: String, record: String, accent: Color, modifier: Modifier, onPlay: () -> Unit) {
    Column(
        modifier
            .clip(RoundedCornerShape(16.dp))
            .background(Color(0x22FFFFFF))
            .border(1.dp, Pal.border, RoundedCornerShape(16.dp))
            .padding(12.dp),
    ) {
        Txt(glyph, 30.sp)
        Txt(title, 15.sp, weight = FontWeight.SemiBold)
        Txt(desc, 12.sp, Pal.dim)
        Spacer(Modifier.height(4.dp))
        Txt(record, 11.sp, Pal.gold)
        Spacer(Modifier.height(8.dp))
        PillButton("Jouer", accent, onClick = onPlay)
    }
}

// ---------------------------------------------------------------------------
// Personnalisation
// ---------------------------------------------------------------------------

private class ShopCat(val label: String, val slot: String, val match: (Item) -> Boolean)

private val STYLE_CATS = listOf(
    ShopCat("Tête", "head") { it.kind == ItemKind.ACCESSORY && it.slot == "head" },
    ShopCat("Visage", "face") { it.kind == ItemKind.ACCESSORY && it.slot == "face" },
    ShopCat("Cou", "neck") { it.kind == ItemKind.ACCESSORY && it.slot == "neck" },
    ShopCat("Auras", "aura") { it.kind == ItemKind.ACCESSORY && it.slot == "aura" },
    ShopCat("Ambiances", "amb") { it.kind == ItemKind.AMBIANCE },
    ShopCat("Thèmes", "") { it.kind == ItemKind.THEME },
)

private val SHOP_CATS = listOf(
    ShopCat("Nourriture", "") { it.kind == ItemKind.FOOD },
    ShopCat("Boissons", "") { it.kind == ItemKind.TONIC },
    ShopCat("Jouets", "") { it.kind == ItemKind.TOY },
) + STYLE_CATS

/** Boutique avec onglets : liste des objets d'une catégorie, achat et équipement. */
@Composable
private fun ShopTabs(vm: GameViewModel, accent: Color, cats: List<ShopCat>) {
    var sel by remember { mutableStateOf(0) }
    val cat = cats[sel.coerceIn(0, cats.lastIndex)]
    val s = vm.state
    Row(
        Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
        horizontalArrangement = Arrangement.spacedBy(6.dp),
    ) {
        cats.forEachIndexed { i, c ->
            Box(
                Modifier
                    .clip(RoundedCornerShape(16.dp))
                    .background(if (i == sel) accent.copy(alpha = 0.45f) else Color(0x22FFFFFF))
                    .clickable { sel = i }
                    .padding(horizontal = 12.dp, vertical = 6.dp),
            ) {
                Txt(c.label, 12.sp, if (i == sel) Color.White else Pal.dim, FontWeight.SemiBold)
            }
        }
    }
    Spacer(Modifier.height(6.dp))
    val hasWorn = when (cat.slot) {
        "" -> false
        "amb" -> s.ambiance != "amb_none"
        else -> s.worn(cat.slot) != "acc_none"
    }
    if (hasWorn) {
        PillButton("Retirer", Pal.red) { vm.unequip(cat.slot) }
        Spacer(Modifier.height(6.dp))
    }
    Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(5.dp)) {
        for (item in Catalog.items.filter(cat.match)) ShopRow(vm, item, accent)
    }
}

@Composable
private fun ShopRow(vm: GameViewModel, item: Item, accent: Color) {
    val s = vm.state
    val wearable = item.kind == ItemKind.ACCESSORY || item.kind == ItemKind.THEME || item.kind == ItemKind.AMBIANCE
    val stock = s.inventory[item.id] ?: 0
    val owned = if (wearable) item.id in s.owned else item.kind == ItemKind.TOY && stock > 0
    val equipped = wearable && s.isEquipped(item)
    Row(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(if (equipped) accent.copy(alpha = 0.25f) else Color(0x22FFFFFF))
            .padding(8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Txt(item.glyph, 22.sp)
        Column(Modifier.weight(1f).padding(horizontal = 8.dp)) {
            Txt(item.name, 13.sp, weight = FontWeight.Medium, maxLines = 1)
            Txt(item.desc, 10.sp, Pal.dim, maxLines = 2)
            if (!wearable && item.kind != ItemKind.TOY && stock > 0) Txt("En stock : $stock", 10.sp, Pal.gold)
        }
        if (equipped) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Filled.Check, null, tint = accent, modifier = Modifier.size(16.dp))
                Txt("Équipé", 12.sp, accent)
            }
        } else if (wearable && owned) {
            PillButton("Équiper", accent) { vm.equip(item.id) }
        } else if (owned) {
            Txt("Possédé", 12.sp, Pal.dim)
        } else {
            PillButton("${item.price} ${if (item.useGems) "gemmes" else "pièces"}", accent) {
                vm.buy(item.id)
                if (wearable && item.id in vm.state.owned) vm.equip(item.id)
            }
        }
    }
}

@Composable
fun StyleScreen(vm: GameViewModel, accent: Color) {
    val s = vm.state
    Row(Modifier.fillMaxSize()) {
        Panel(Modifier.weight(1.5f).fillMaxHeight()) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Txt("Personnalisation", 16.sp, weight = FontWeight.Bold, modifier = Modifier.weight(1f))
                Txt("${s.coins} pièces  •  ${s.gems} gemmes", 11.sp, Pal.gold)
            }
            Spacer(Modifier.height(6.dp))
            ShopTabs(vm, accent, STYLE_CATS)
        }
        Spacer(Modifier.weight(1f))
    }
}

// ---------------------------------------------------------------------------
// Galerie
// ---------------------------------------------------------------------------

private class MemoryDef(val id: String, val title: String, val hint: String, val face: Face)

private val MEMORIES = listOf(
    MemoryDef("first_pet", "Premier câlin", "Caresse Nyxie une première fois.",
        Face(happyEyes = true, mouth = Mouth.SMILE, blush = true)),
    MemoryDef("first_meal", "Premier repas", "Donne-lui à manger.",
        Face(eye = 0.9f, mouth = Mouth.BIG, mouthOpen = 0.55f)),
    MemoryDef("first_game", "Première partie", "Termine un mini-jeu.",
        Face(happyEyes = true, mouth = Mouth.BIG, mouthOpen = 0.9f, blush = true)),
    MemoryDef("gift", "Surprise !", "Ouvre un cadeau.",
        Face(eye = 1f, mouth = Mouth.BIG, mouthOpen = 1f, blush = true)),
    MemoryDef("lvl5", "Niveau 5", "Atteins le niveau 5.",
        Face(eye = 0.5f, mouth = Mouth.SMILE, blush = true)),
    MemoryDef("lvl10", "Niveau 10", "Atteins le niveau 10.",
        Face(eye = 1f, mouth = Mouth.OPEN, blush = true)),
)

@Composable
fun GalleryScreen(vm: GameViewModel) {
    val s = vm.state
    Panel(Modifier.fillMaxSize()) {
        Txt("Galerie de souvenirs  (${s.memories.count { id -> MEMORIES.any { it.id == id } }} / ${MEMORIES.size})", 16.sp, weight = FontWeight.Bold)
        Spacer(Modifier.height(8.dp))
        for (row in 0 until 2) {
            Row(
                Modifier.weight(1f).fillMaxWidth().padding(bottom = if (row == 0) 8.dp else 0.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                for (col in 0 until 3) {
                    val m = MEMORIES[row * 3 + col]
                    val unlocked = m.id in s.memories
                    Box(
                        Modifier
                            .weight(1f)
                            .fillMaxHeight()
                            .clip(RoundedCornerShape(14.dp))
                            .border(1.dp, Pal.border, RoundedCornerShape(14.dp)),
                    ) {
                        if (unlocked) {
                            NyxieScene(
                                state = s, reaction = Reaction.NONE, modifier = Modifier.fillMaxSize(),
                                region = THUMB_REGION, forcedFace = m.face,
                            )
                        } else {
                            Box(Modifier.fillMaxSize().background(Color(0xFF1A0F36)), contentAlignment = Alignment.Center) {
                                Icon(Icons.Filled.Lock, null, tint = Pal.dim, modifier = Modifier.size(28.dp))
                            }
                        }
                        Column(
                            Modifier
                                .align(Alignment.BottomStart)
                                .fillMaxWidth()
                                .background(Brush.verticalGradient(listOf(Color.Transparent, Color(0xCC000000))))
                                .padding(8.dp),
                        ) {
                            Txt(m.title, 12.sp, weight = FontWeight.SemiBold, maxLines = 1)
                            if (!unlocked) Txt(m.hint, 10.sp, Pal.dim, maxLines = 2)
                        }
                    }
                }
            }
        }
    }
}

// ---------------------------------------------------------------------------
// Inventaire et boutique
// ---------------------------------------------------------------------------

@Composable
fun BagScreen(vm: GameViewModel, accent: Color) {
    val s = vm.state
    val bag = Catalog.items.filter {
        (it.kind == ItemKind.FOOD || it.kind == ItemKind.TONIC || it.kind == ItemKind.TOY) && (s.inventory[it.id] ?: 0) > 0
    }
    Row(Modifier.fillMaxSize(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        Panel(Modifier.weight(1f).fillMaxHeight()) {
            Txt("Inventaire", 16.sp, weight = FontWeight.Bold)
            Spacer(Modifier.height(6.dp))
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                if (bag.isEmpty()) Txt("Ton sac est vide. Visite la boutique !", 13.sp, Pal.dim)
                for (item in bag) {
                    Row(
                        Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(Color(0x22FFFFFF)).padding(8.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Txt(item.glyph, 22.sp)
                        Column(Modifier.weight(1f).padding(horizontal = 8.dp)) {
                            Txt(item.name, 13.sp, weight = FontWeight.Medium, maxLines = 1)
                            Txt(
                                if (item.kind == ItemKind.TOY) "Jouet" else "x${s.inventory[item.id] ?: 0}",
                                11.sp, Pal.gold,
                            )
                        }
                        PillButton(if (item.kind == ItemKind.TOY) "Jouer" else "Utiliser", accent) { vm.useItem(item.id) }
                    }
                }
            }
        }
        Panel(Modifier.weight(1f).fillMaxHeight()) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Txt("Boutique", 16.sp, weight = FontWeight.Bold, modifier = Modifier.weight(1f))
                Txt("${s.coins} pièces  •  ${s.gems} gemmes", 11.sp, Pal.gold)
            }
            Spacer(Modifier.height(6.dp))
            ShopTabs(vm, accent, SHOP_CATS)
        }
    }
}

// ---------------------------------------------------------------------------
// Évolution
// ---------------------------------------------------------------------------

@Composable
fun EvolutionScreen(vm: GameViewModel, accent: Color) {
    val s = vm.state
    val steps = listOf(
        Triple(1, "Petite Nyxie", "Les débuts de votre aventure."),
        Triple(5, "Nyxie rêveuse", "Souvenir « Niveau 5 » débloqué."),
        Triple(10, "Nyxie étoilée", "Souvenir « Niveau 10 » débloqué."),
        Triple(20, "Gardienne lunaire", "Le plus haut rang."),
    )
    Panel(Modifier.fillMaxSize()) {
        Column(Modifier.verticalScroll(rememberScrollState())) {
            Txt("Évolution", 16.sp, weight = FontWeight.Bold)
            Spacer(Modifier.height(6.dp))
            Txt(stageFor(s.level), 22.sp, accent, FontWeight.Bold)
            Txt("Niveau ${s.level}  •  ${s.xp} / ${xpNeeded(s.level)} XP", 12.sp, Pal.dim)
            Spacer(Modifier.height(4.dp))
            Bar(s.xp.toFloat() / xpNeeded(s.level), accent)
            Spacer(Modifier.height(10.dp))
            for ((lvl, name, desc) in steps) {
                val reached = s.level >= lvl
                Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        if (reached) Icons.Filled.Check else Icons.Filled.Lock, null,
                        tint = if (reached) accent else Pal.dim, modifier = Modifier.size(20.dp),
                    )
                    Column(Modifier.padding(start = 8.dp)) {
                        Txt("Niveau $lvl  –  $name", 13.sp, if (reached) Pal.text else Pal.dim, FontWeight.Medium)
                        Txt(desc, 11.sp, Pal.dim)
                    }
                }
            }
            Spacer(Modifier.height(10.dp))
            Txt("Statistiques", 12.sp, Pal.dim, FontWeight.SemiBold)
            Txt("Interactions au total : ${s.totalInteractions}", 12.sp)
            Txt("Record étoiles filantes : ${s.bestStars}", 12.sp)
            Txt("Record mémoire lunaire : ${if (s.bestMemory == 0) "–" else "${s.bestMemory} coups"}", 12.sp)
            Txt("Souvenirs débloqués : ${s.memories.count { id -> MEMORIES.any { it.id == id } }} / ${MEMORIES.size}", 12.sp)
        }
    }
}

// ---------------------------------------------------------------------------
// Paramètres
// ---------------------------------------------------------------------------

@Composable
fun SettingsScreen(vm: GameViewModel, accent: Color) {
    val s = vm.state
    var nameDraft by remember { mutableStateOf(s.name) }
    var showReset by remember { mutableStateOf(false) }
    Panel(Modifier.fillMaxSize()) {
        Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Txt("Paramètres", 16.sp, weight = FontWeight.Bold)
            Txt("Nom de ton compagnon", 12.sp, Pal.dim)
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Box(
                    Modifier
                        .weight(1f)
                        .height(42.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(Color(0x22FFFFFF))
                        .border(1.dp, Pal.border, RoundedCornerShape(12.dp))
                        .padding(horizontal = 12.dp),
                    contentAlignment = Alignment.CenterStart,
                ) {
                    BasicTextField(
                        value = nameDraft,
                        onValueChange = { nameDraft = it.take(14) },
                        singleLine = true,
                        textStyle = TextStyle(color = Pal.text, fontSize = 15.sp),
                        cursorBrush = SolidColor(accent),
                        modifier = Modifier.fillMaxWidth(),
                    )
                }
                PillButton("Enregistrer", accent) { vm.rename(nameDraft) }
            }
            SwitchRow("Sons de l'application", s.soundsOn, accent) { vm.setSounds(it) }
            SwitchRow("Animations de Nyxie", s.animationsOn, accent) { vm.setAnimations(it) }
            Txt(
                "Tout fonctionne localement sur ton téléphone : aucune IA distante, aucun compte, " +
                    "rien n'est envoyé sur internet. La progression est enregistrée automatiquement.",
                12.sp, Pal.dim,
            )
            Txt("Outils de test", 12.sp, Pal.dim)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                PillButton("+500 pièces, +20 gemmes", accent) { vm.testBoost() }
                PillButton("Tout débloquer", accent) { vm.unlockEverything() }
            }
            PillButton("Réinitialiser la progression", Pal.red) { showReset = true }
        }
    }
    if (showReset) {
        AlertDialog(
            onDismissRequest = { showReset = false },
            containerColor = Color(0xFF1A0F36),
            title = { Txt("Tout recommencer ?", 18.sp, weight = FontWeight.Bold) },
            text = { Txt("Le niveau, les pièces, l'inventaire et les souvenirs seront effacés.", 14.sp, Pal.dim) },
            confirmButton = {
                TextButton(onClick = {
                    vm.resetAll()
                    nameDraft = "Nyxie"
                    showReset = false
                }) { Text("Réinitialiser", color = Pal.red) }
            },
            dismissButton = { TextButton(onClick = { showReset = false }) { Text("Annuler", color = Pal.dim) } },
        )
    }
}

@Composable
private fun SwitchRow(label: String, checked: Boolean, accent: Color, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Txt(label, 14.sp, modifier = Modifier.weight(1f))
        Switch(
            checked = checked,
            onCheckedChange = onChange,
            colors = SwitchDefaults.colors(checkedTrackColor = accent, checkedThumbColor = Color.White),
        )
    }
}
