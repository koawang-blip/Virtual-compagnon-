package com.lumina.nyxie

import android.content.ActivityNotFoundException
import android.content.Intent
import android.os.Bundle
import android.speech.RecognizerIntent
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.remember
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.res.imageResource
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import java.util.Locale

class MainActivity : ComponentActivity() {

    private val vm: GameViewModel by viewModels()

    private val micLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            val text = result.data
                ?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)
                ?.firstOrNull()
            if (!text.isNullOrBlank()) {
                vm.screen = Screen.CHAT
                vm.send(text)
            }
        }

    private fun startMic() {
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.FRANCE.toLanguageTag())
            putExtra(RecognizerIntent.EXTRA_PROMPT, "Parle à ${vm.state.name}…")
        }
        try {
            micLauncher.launch(intent)
        } catch (e: ActivityNotFoundException) {
            vm.showToast("La saisie vocale n'est pas disponible sur cet appareil.")
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        val controller = WindowCompat.getInsetsController(window, window.decorView)
        controller.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        controller.hide(WindowInsetsCompat.Type.systemBars())

        setContent {
            val assets = Assets(
                scene = ImageBitmap.imageResource(R.drawable.nyxie_pet_scene),
                lidL = ImageBitmap.imageResource(R.drawable.nyxie_lid_l),
                lidR = ImageBitmap.imageResource(R.drawable.nyxie_lid_r),
                mouthCover = ImageBitmap.imageResource(R.drawable.nyxie_mouth_cover),
            )
            val keep = remember { assets }
            MaterialTheme(colorScheme = darkColorScheme()) {
                CompositionLocalProvider(LocalAssets provides keep) {
                    NyxieApp(vm) { startMic() }
                }
            }
        }
    }

    override fun onStop() {
        vm.saveNow()
        super.onStop()
    }
}
