package com.lumina.nyxie

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.widget.RemoteViews

/** Widget d'écran d'accueil : Nyxie, son humeur et ses trois jauges. Un tap ouvre l'application. */
class NyxieWidget : AppWidgetProvider() {
    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) {
        for (id in ids) manager.updateAppWidget(id, build(context))
    }

    companion object {
        /** Met à jour tous les widgets posés (appelé quand on quitte l'application). */
        fun refresh(context: Context) {
            try {
                val mgr = AppWidgetManager.getInstance(context)
                val ids = mgr.getAppWidgetIds(ComponentName(context, NyxieWidget::class.java))
                if (ids.isNotEmpty()) for (id in ids) mgr.updateAppWidget(id, build(context))
            } catch (e: Exception) {
            }
        }

        private fun moodText(s: GameState): String = when {
            s.sleeping -> "Elle dort 💤"
            s.hunger < 0.2f -> "Elle a très faim"
            s.energy < 0.2f -> "Elle est épuisée"
            s.affection < 0.25f -> "Elle a besoin d'un câlin"
            s.mood > 0.75f -> "Heureuse ✨"
            s.mood > 0.5f -> "Contente"
            s.mood > 0.3f -> "Pensive"
            else -> "Un peu triste"
        }

        private fun build(c: Context): RemoteViews {
            val s0 = Store.load(c)
            val s = if (s0.lastSeen > 0L) decay(s0, System.currentTimeMillis() - s0.lastSeen) else s0
            val v = RemoteViews(c.packageName, R.layout.widget_nyxie)
            v.setTextViewText(R.id.widget_title, "${s.name}  •  niveau ${s.level}")
            v.setTextViewText(R.id.widget_mood, moodText(s))
            v.setProgressBar(R.id.widget_hunger, 100, (s.hunger * 100).toInt().coerceIn(0, 100), false)
            v.setProgressBar(R.id.widget_energy, 100, (s.energy * 100).toInt().coerceIn(0, 100), false)
            v.setProgressBar(R.id.widget_affection, 100, (s.affection * 100).toInt().coerceIn(0, 100), false)
            val open = PendingIntent.getActivity(
                c, 7, Intent(c, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP),
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
            )
            v.setOnClickPendingIntent(R.id.widget_root, open)
            return v
        }
    }
}
