package com.lumina.nyxie

import android.app.Application
import android.media.AudioManager
import android.media.ToneGenerator
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlin.math.max
import kotlin.math.min
import kotlin.random.Random

data class ChatMsg(val fromUser: Boolean, val text: String, val at: Long)

class GameViewModel(app: Application) : AndroidViewModel(app) {

    var state by mutableStateOf(GameState())
        private set
    var screen by mutableStateOf(Screen.HOME)
    var reaction by mutableStateOf(Reaction.NONE)
        private set
    var speech by mutableStateOf<String?>(null)
        private set
    var toast by mutableStateOf<String?>(null)
        private set
    var now by mutableStateOf(System.currentTimeMillis())
        private set
    val chat = mutableStateListOf<ChatMsg>()

    private var reactionJob: Job? = null
    private var speechJob: Job? = null
    private var toastJob: Job? = null
    private var dirty = false
    private var idleTicks = 0
    private var tone: ToneGenerator? = null

    init {
        val loaded = Store.load(getApplication())
        val t = System.currentTimeMillis()
        val first = loaded.lastSeen == 0L
        var s = if (first) loaded else decay(loaded, t - loaded.lastSeen)
        s = s.copy(lastSeen = t)
        state = s
        now = t
        if (first) {
            say("Coucou ! Moi c'est ${s.name}. Prends soin de moi, d'accord ?", 6000)
        } else {
            say(
                when {
                    s.sleeping -> "Zzz…"
                    s.hunger < 0.3f -> "Te revoilà ! J'ai un peu faim…"
                    else -> "Ravie de te retrouver !"
                },
                5000,
            )
        }
        viewModelScope.launch {
            var n = 0
            while (true) {
                delay(1000)
                tickOnce()
                n++
                if (n % 5 == 0) saveNow()
            }
        }
    }

    // -----------------------------------------------------------------------
    // Infrastructure
    // -----------------------------------------------------------------------

    private fun update(block: (GameState) -> GameState) {
        val before = state
        var after = block(before)
        if (after.level >= 5) after = after.unlock("lvl5")
        if (after.level >= 10) after = after.unlock("lvl10")
        state = after
        dirty = true
        if (after.level > before.level) {
            showToast("Niveau ${after.level} ! +${after.level - before.level} gemme")
            say("Je grandis ! Niveau ${after.level} !", 4500)
            beep(3)
        }
    }

    fun saveNow() {
        Store.save(getApplication(), state)
        dirty = false
    }

    override fun onCleared() {
        saveNow()
        tone?.release()
        super.onCleared()
    }

    fun say(text: String, ms: Long = 4200) {
        speech = text
        speechJob?.cancel()
        speechJob = viewModelScope.launch {
            delay(ms)
            speech = null
        }
    }

    private fun react(r: Reaction, ms: Long) {
        reaction = r
        reactionJob?.cancel()
        reactionJob = viewModelScope.launch {
            delay(ms)
            reaction = Reaction.NONE
        }
    }

    fun showToast(text: String) {
        toast = text
        toastJob?.cancel()
        toastJob = viewModelScope.launch {
            delay(2600)
            toast = null
        }
    }

    private fun beep(kind: Int) {
        if (!state.soundsOn) return
        try {
            if (tone == null) tone = ToneGenerator(AudioManager.STREAM_MUSIC, 45)
            val code = when (kind) {
                1 -> ToneGenerator.TONE_PROP_ACK
                2 -> ToneGenerator.TONE_PROP_BEEP
                3 -> ToneGenerator.TONE_PROP_PROMPT
                else -> ToneGenerator.TONE_PROP_BEEP2
            }
            tone?.startTone(code, 140)
        } catch (e: Exception) {
            // Pas de son disponible : on ignore.
        }
    }

    private fun tickOnce() {
        val t = System.currentTimeMillis()
        now = t
        var s = decay(state, t - state.lastSeen).copy(lastSeen = t)
        if (s.sleeping && s.energy >= 0.99f) {
            s = s.copy(sleeping = false)
            say("Bien dormi ! Je suis en pleine forme !", 5000)
        }
        state = s
        dirty = true
        // Fin d'activité
        val a = s.activityId?.let { Catalog.activityById[it] }
        if (a != null && t >= s.activityStart + a.durationSec * 1000L) {
            finishActivity(false)
        }
        // Petite phrase spontanée de temps en temps
        idleTicks++
        if (idleTicks >= 45 && speech == null && !state.sleeping && reaction == Reaction.NONE) {
            idleTicks = 0
            say(idleLines(state).random(), 4000)
        }
    }

    private fun sleepingGate(): Boolean {
        if (state.sleeping) {
            say("Chut… ${state.name} dort. Touche-la pour la réveiller.", 3500)
            return true
        }
        return false
    }

    // -----------------------------------------------------------------------
    // Actions principales
    // -----------------------------------------------------------------------

    fun tapNyxie() {
        if (state.sleeping) wake() else pet()
    }

    fun pet() {
        if (sleepingGate()) return
        val s = state
        val gain = if (s.affection > 0.95f) 0.01f else 0.08f
        update { it.bump(a = gain).gainXp(3).log("PET", System.currentTimeMillis()).unlock("first_pet") }
        react(Reaction.PET, 2400)
        say(petLines(s).random(), 3500)
        beep(1)
    }

    fun feed(itemId: String) {
        val item = Catalog.byId[itemId] ?: return
        if (sleepingGate()) return
        val s = state
        if ((s.inventory[itemId] ?: 0) <= 0) {
            showToast("Tu n'as plus de ${item.name}.")
            return
        }
        if (item.kind == ItemKind.FOOD && s.hunger > 0.97f) {
            say("Je n'ai vraiment plus faim, merci !", 3000)
            return
        }
        update {
            it.takeItem(itemId)
                .bump(h = item.hunger, e = item.energy, a = item.affection)
                .gainXp(item.xp)
                .log("EAT", System.currentTimeMillis())
                .unlock("first_meal")
        }
        react(if (item.kind == ItemKind.TONIC) Reaction.GIFT else Reaction.EAT, 2800)
        say(eatLines(item).random(), 3800)
        beep(2)
    }

    fun play(toyId: String? = null) {
        if (sleepingGate()) return
        val s = state
        if (s.energy < 0.15f) {
            say("Je suis trop fatiguée pour jouer… Un petit dodo ?", 3800)
            return
        }
        val toy = toyId?.let { Catalog.byId[it] }
        val aff = 0.08f + (toy?.affection ?: 0f)
        val en = -0.08f + (toy?.energy ?: 0f)
        update {
            it.bump(e = en, a = aff).gainXp(6).copy(coins = it.coins + Random.nextInt(2, 5))
                .log("PLAY", System.currentTimeMillis())
        }
        react(Reaction.PLAY, 2800)
        say(playLines().random(), 3500)
        beep(1)
    }

    fun useItem(itemId: String) {
        val item = Catalog.byId[itemId] ?: return
        when (item.kind) {
            ItemKind.FOOD, ItemKind.TONIC -> feed(itemId)
            ItemKind.TOY -> play(itemId)
            else -> {}
        }
    }

    fun talk() {
        if (sleepingGate()) return
        val line = talkLines(state).random()
        update { it.bump(a = 0.02f).gainXp(2).log("TALK", System.currentTimeMillis()) }
        react(Reaction.TALK, 2800)
        say(line, 4500)
        chat.add(ChatMsg(false, line, System.currentTimeMillis()))
        beep(4)
    }

    fun send(text: String) {
        val t = text.trim()
        if (t.isEmpty()) return
        chat.add(ChatMsg(true, t, System.currentTimeMillis()))
        if (state.sleeping) {
            chat.add(ChatMsg(false, "Zzz… zzz…", System.currentTimeMillis()))
            return
        }
        val answer = replyTo(t, state)
        update { it.bump(a = 0.01f).gainXp(2).log("TALK", System.currentTimeMillis()) }
        viewModelScope.launch {
            delay(600)
            chat.add(ChatMsg(false, answer, System.currentTimeMillis()))
            say(answer, 4500)
            react(Reaction.TALK, 2800)
            beep(4)
        }
    }

    fun careBath() {
        if (sleepingGate()) return
        update { it.bump(h = -0.03f, a = 0.12f).gainXp(6).log("CARE", System.currentTimeMillis()) }
        react(Reaction.PET, 2800)
        say("Splish splash ! Un bain de lune, quel bonheur !", 4000)
        beep(1)
    }

    fun careBrush() {
        if (sleepingGate()) return
        update { it.bump(a = 0.08f).gainXp(4).log("CARE", System.currentTimeMillis()) }
        react(Reaction.PET, 2400)
        say("Mes petites plumes brillent à nouveau !", 3800)
        beep(1)
    }

    fun toggleSleep() {
        val s = state
        if (s.sleeping) {
            wake()
        } else if (s.energy > 0.9f) {
            say("Je n'ai pas sommeil du tout !", 3000)
        } else {
            update { it.copy(sleeping = true, activityId = null).log("SLEEP", System.currentTimeMillis()) }
            reaction = Reaction.NONE
            say("Bonne nuit… zzz", 3000)
            showToast("${s.name} s'endort. Son énergie remonte pendant son sommeil.")
        }
    }

    fun wake() {
        if (!state.sleeping) return
        update { it.copy(sleeping = false) }
        say("Hmm… déjà réveillée ? *bâille*", 4000)
    }

    // -----------------------------------------------------------------------
    // Activités
    // -----------------------------------------------------------------------

    fun startActivity(id: String) {
        if (sleepingGate()) return
        val a = Catalog.activityById[id] ?: return
        if (state.activityId != null) {
            showToast("Une activité est déjà en cours.")
            return
        }
        if (a.energyDelta < 0f && state.energy < 0.15f) {
            say("Je suis trop fatiguée pour ça…", 3500)
            return
        }
        update { it.copy(activityId = id, activityStart = System.currentTimeMillis()) }
        react(Reaction.ACTIVITY, 3200)
        say(a.line, 4500)
    }

    fun finishActivity(early: Boolean) {
        val s = state
        val a = s.activityId?.let { Catalog.activityById[it] } ?: return
        val total = a.durationSec * 1000f
        val progress = ((System.currentTimeMillis() - s.activityStart) / total).coerceIn(0f, 1f)
        val f = if (early) progress * 0.5f else 1f
        val coins = (a.coins * f).toInt()
        update {
            it.copy(activityId = null, activityStart = 0L)
                .bump(e = a.energyDelta * f, a = a.affection * f)
                .gainXp((a.xp * f).toInt())
                .copy(coins = it.coins + coins)
                .log("ACT", System.currentTimeMillis())
        }
        react(Reaction.PET, 2400)
        say(if (early) "On s'arrête déjà ? D'accord…" else "Activité terminée ! +$coins pièces", 4000)
        if (!early) beep(3)
    }

    // -----------------------------------------------------------------------
    // Cadeau, boutique, style
    // -----------------------------------------------------------------------

    fun giftReady(): Boolean = now - state.lastGift >= GIFT_COOLDOWN_MS

    fun giftRemainingMs(): Long = max(0L, GIFT_COOLDOWN_MS - (now - state.lastGift))

    fun claimGift() {
        if (!giftReady()) {
            showToast("Prochain cadeau dans ${remainingText(giftRemainingMs())}.")
            say("Reviens plus tard, j'en prépare un autre !", 3500)
            return
        }
        val roll = Random.nextInt(100)
        val t = System.currentTimeMillis()
        var message: String
        when {
            roll < 45 -> {
                val c = Random.nextInt(30, 61)
                update { it.copy(coins = it.coins + c, lastGift = t).gainXp(8).log("GIFT", t).unlock("gift") }
                message = "Un cadeau ! +$c pièces !"
            }
            roll < 75 -> {
                val food = Catalog.items.filter { it.kind == ItemKind.FOOD && it.price <= 70 }.random()
                update { it.addItem(food.id).copy(lastGift = t).gainXp(8).log("GIFT", t).unlock("gift") }
                message = "Un cadeau ! ${food.glyph} ${food.name} !"
            }
            roll < 90 -> {
                val g = Random.nextInt(1, 3)
                update { it.copy(gems = it.gems + g, lastGift = t).gainXp(8).log("GIFT", t).unlock("gift") }
                message = "Un cadeau ! +$g gemme !"
            }
            else -> {
                update { it.addItem("nectar").copy(lastGift = t).gainXp(8).log("GIFT", t).unlock("gift") }
                message = "Un cadeau ! 🍯 Nectar des rêves !"
            }
        }
        react(Reaction.GIFT, 3400)
        say(message, 4500)
        showToast(message)
        beep(3)
    }

    fun buy(itemId: String) {
        val item = Catalog.byId[itemId] ?: return
        val s = state
        val permanent = item.kind == ItemKind.TOY || item.kind == ItemKind.ACCESSORY ||
            item.kind == ItemKind.THEME || item.kind == ItemKind.AMBIANCE
        if (permanent) {
            val has = if (item.kind == ItemKind.TOY) (s.inventory[itemId] ?: 0) > 0 else itemId in s.owned
            if (has) {
                showToast("Tu possèdes déjà cet objet.")
                return
            }
        }
        val money = if (item.useGems) s.gems else s.coins
        if (money < item.price) {
            showToast(if (item.useGems) "Pas assez de gemmes." else "Pas assez de pièces.")
            return
        }
        update {
            var n = if (item.useGems) it.copy(gems = it.gems - item.price) else it.copy(coins = it.coins - item.price)
            n = when (item.kind) {
                ItemKind.ACCESSORY, ItemKind.THEME, ItemKind.AMBIANCE -> n.copy(owned = n.owned + itemId)
                else -> n.addItem(itemId)
            }
            n
        }
        showToast("Acheté : ${item.glyph} ${item.name}")
        beep(2)
    }

    fun equip(itemId: String) {
        val item = Catalog.byId[itemId] ?: return
        if (itemId !in state.owned) return
        when (item.kind) {
            ItemKind.ACCESSORY -> update { it.withWorn(item.slot, itemId) }
            ItemKind.THEME -> update { it.copy(theme = itemId) }
            ItemKind.AMBIANCE -> update { it.copy(ambiance = itemId) }
            else -> return
        }
        say("Oh, c'est joli !", 2500)
        react(Reaction.PET, 1800)
    }

    /** Retire l'objet porté dans un emplacement (head, face, neck, aura) ou l'ambiance (amb). */
    fun unequip(slot: String) {
        if (slot == "amb") update { it.copy(ambiance = "amb_none") } else update { it.withWorn(slot, "acc_none") }
    }

    /** Aide pour tester la boutique. */
    fun testBoost() {
        update { it.copy(coins = it.coins + 500, gems = it.gems + 20) }
        showToast("+500 pièces et +20 gemmes")
    }

    fun unlockEverything() {
        update { s ->
            val all = Catalog.items.filter {
                it.kind == ItemKind.ACCESSORY || it.kind == ItemKind.THEME || it.kind == ItemKind.AMBIANCE
            }.map { it.id }
            val inv = s.inventory.toMutableMap()
            for (i in Catalog.items) if (i.kind == ItemKind.TOY && (inv[i.id] ?: 0) == 0) inv[i.id] = 1
            s.copy(owned = s.owned + all, inventory = inv)
        }
        showToast("Tous les objets sont débloqués.")
    }

    // -----------------------------------------------------------------------
    // Mini-jeux
    // -----------------------------------------------------------------------

    fun finishStars(score: Int) {
        val coins = score / 2 + 2
        update {
            it.bump(e = -0.10f, a = 0.05f).gainXp(score * 2 + 5)
                .copy(coins = it.coins + coins, bestStars = max(it.bestStars, score))
                .log("PLAY", System.currentTimeMillis()).unlock("first_game")
        }
        react(Reaction.PLAY, 3000)
        say("$score étoiles attrapées ! +$coins pièces", 4500)
        beep(3)
    }

    fun finishMemory(moves: Int) {
        val coins = max(5, 40 - moves * 2)
        update {
            it.bump(e = -0.06f, a = 0.06f).gainXp(20)
                .copy(coins = it.coins + coins, bestMemory = if (it.bestMemory == 0) moves else min(it.bestMemory, moves))
                .log("PLAY", System.currentTimeMillis()).unlock("first_game")
        }
        react(Reaction.PLAY, 3000)
        say("Bravo, en $moves coups ! +$coins pièces", 4500)
        beep(3)
    }

    // -----------------------------------------------------------------------
    // Paramètres
    // -----------------------------------------------------------------------

    fun rename(newName: String) {
        val n = newName.trim().take(14)
        if (n.isEmpty()) {
            showToast("Choisis un nom d'au moins une lettre.")
            return
        }
        update { it.copy(name = n) }
        say("$n… j'adore mon nom !", 3500)
        showToast("Nouveau nom enregistré.")
    }

    fun setSounds(on: Boolean) = update { it.copy(soundsOn = on) }

    fun setAnimations(on: Boolean) = update { it.copy(animationsOn = on) }

    fun resetAll() {
        Store.clear(getApplication())
        chat.clear()
        state = GameState(lastSeen = System.currentTimeMillis())
        dirty = true
        screen = Screen.HOME
        say("Coucou ! On recommence ensemble ?", 5000)
        showToast("Progression réinitialisée.")
    }
}
