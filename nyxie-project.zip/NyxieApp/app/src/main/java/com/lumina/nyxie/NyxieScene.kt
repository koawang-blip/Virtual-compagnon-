package com.lumina.nyxie

import androidx.compose.foundation.Canvas
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.FilterQuality
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.clipRect
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.drawscope.withTransform
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import androidx.compose.foundation.gestures.detectTapGestures
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin
import kotlin.random.Random

// ---------------------------------------------------------------------------
// Expressions du visage
// ---------------------------------------------------------------------------

enum class Mouth { OPEN, SMILE, SAD, O, BIG, FLAT }

data class Face(
    val eye: Float = 1f,              // 1 = yeux grands ouverts, 0 = fermés
    val happyEyes: Boolean = false,   // yeux rieurs ^ ^
    val mouth: Mouth = Mouth.OPEN,    // OPEN = bouche d'origine du dessin
    val mouthOpen: Float = 1f,        // ouverture de la bouche BIG (0..1)
    val blush: Boolean = false,
    val tear: Boolean = false,
    val zzz: Boolean = false,
)

class Assets(
    val scene: ImageBitmap,
    val lidL: ImageBitmap,
    val lidR: ImageBitmap,
    val mouthCover: ImageBitmap,
)

val LocalAssets = staticCompositionLocalOf<Assets> { error("Assets non fournis") }

private const val SCENE_W = 1672f
private const val SCENE_H = 941f
private const val RAD_TO_DEG = 57.29578f
private const val PIF = 3.14159265f

private class EyeGeo(
    val cx: Float, val cy: Float, val rx: Float, val ry: Float, val rot: Float,
    val outerLeft: Boolean, val patchX: Float, val patchY: Float,
)

private val EYE_L = EyeGeo(718f, 476f, 66f, 44f, -0.12f, true, 632f, 414f)
private val EYE_R = EyeGeo(929f, 432f, 56f, 46f, 0.18f, false, 854f, 366f)

private val LASH = Color(0xFF2A1030)
private val MOUTH_LINE = Color(0xFF4A1738)
private val MOUTH_FILL = Color(0xFFE8546E)
private val TONGUE = Color(0xFFFF9AA8)
private val O_FILL = Color(0xFFD9506A)

/** Choisit l'expression de Nyxie à partir de son état et de ce qu'elle est en train de vivre. */
fun resolveFace(s: GameState, r: Reaction, t: Float): Face {
    if (s.sleeping) return Face(eye = 0f, mouth = Mouth.FLAT, zzz = true)
    val wob = abs(sin(t * 9f))
    when (r) {
        Reaction.PET -> return Face(
            happyEyes = true, mouth = Mouth.BIG,
            mouthOpen = 0.30f + 0.15f * abs(sin(t * 3f)), blush = true,
        )
        Reaction.EAT -> return Face(
            eye = 0.9f, mouth = Mouth.BIG, mouthOpen = 0.12f + 0.62f * abs(sin(t * 7f)), blush = true,
        )
        Reaction.PLAY -> return Face(happyEyes = true, mouth = Mouth.BIG, mouthOpen = 0.85f, blush = true)
        Reaction.TALK -> return Face(eye = 1f, mouth = Mouth.BIG, mouthOpen = 0.18f + 0.62f * wob)
        Reaction.GIFT -> return Face(eye = 1f, mouth = Mouth.BIG, mouthOpen = 1f, blush = true)
        Reaction.ACTIVITY -> return Face(eye = 0.55f, mouth = Mouth.SMILE, blush = true)
        Reaction.NONE -> {}
    }
    if (s.energy < 0.2f) {
        val y = t % 9f
        return if (y < 2f) {
            Face(eye = 0.1f, mouth = Mouth.BIG, mouthOpen = sin(y / 2f * PIF).coerceIn(0f, 1f))
        } else {
            Face(eye = 0.35f, mouth = Mouth.FLAT)
        }
    }
    if (s.hunger < 0.2f) return Face(eye = 0.85f, mouth = Mouth.O)
    if (s.affection < 0.25f) return Face(eye = 0.7f, mouth = Mouth.SAD, tear = true)
    val m = s.mood
    return when {
        m > 0.75f -> Face(mouth = Mouth.OPEN, blush = true)
        m > 0.5f -> Face(mouth = Mouth.SMILE)
        m > 0.3f -> Face(eye = 0.9f, mouth = Mouth.FLAT)
        else -> Face(eye = 0.75f, mouth = Mouth.SAD)
    }
}

// ---------------------------------------------------------------------------
// Particules (cœurs, miettes, étincelles, Zzz, larmes)
// ---------------------------------------------------------------------------

private class Particle(
    var x: Float, var y: Float, var vx: Float, var vy: Float,
    var life: Float, val maxLife: Float, val kind: Int, val size: Float,
)

private const val K_HEART = 0
private const val K_CRUMB = 1
private const val K_SPARK = 2
private const val K_ZZZ = 3
private const val K_TEAR = 4

private class Holder {
    var face = Face()
    var eye = 1f
    var blink = 0f
    var jump = 0f
    val parts = ArrayList<Particle>()
    val acc = FloatArray(6)
}

private fun rnd(): Float = Random.nextFloat()

private fun step(h: Holder, s: GameState, r: Reaction, t: Float, dt: Float) {
    val f = resolveFace(s, r, t)
    h.face = f
    h.eye += (f.eye - h.eye) * min(1f, dt * 12f)

    // Clignement (parfois double)
    val n = (t / 4.1f).toInt()
    val cyc = t % 4.1f
    var b = 0f
    if (cyc < 0.16f) {
        b = sin(cyc / 0.16f * PIF)
    } else if (n % 3 == 0 && cyc > 0.30f && cyc < 0.46f) {
        b = sin((cyc - 0.30f) / 0.16f * PIF)
    }
    h.blink = b
    h.jump = if (r == Reaction.PLAY) -abs(sin(t * 6f)) * 18f else 0f

    if (s.animationsOn) {
        fun emit(idx: Int, rate: Float, make: () -> Particle) {
            h.acc[idx] += rate * dt
            while (h.acc[idx] >= 1f) {
                h.acc[idx] -= 1f
                h.parts.add(make())
            }
        }
        when (r) {
            Reaction.PET -> emit(0, 3.2f) {
                Particle(770f + rnd() * 220f, 330f + rnd() * 60f, (rnd() - 0.5f) * 30f, -60f - rnd() * 40f,
                    1.4f, 1.4f, K_HEART, 16f + rnd() * 12f)
            }
            Reaction.EAT -> emit(1, 9f) {
                Particle(815f + rnd() * 35f, 525f, (rnd() - 0.5f) * 140f, -120f - rnd() * 80f,
                    0.8f, 0.8f, K_CRUMB, 4f + rnd() * 4f)
            }
            Reaction.PLAY -> emit(2, 8f) {
                Particle(600f + rnd() * 500f, 250f + rnd() * 350f, (rnd() - 0.5f) * 40f, -30f - rnd() * 30f,
                    1f, 1f, K_SPARK, 10f + rnd() * 10f)
            }
            Reaction.GIFT -> emit(2, 22f) {
                Particle(560f + rnd() * 600f, 230f + rnd() * 400f, (rnd() - 0.5f) * 60f, -40f - rnd() * 50f,
                    1.1f, 1.1f, K_SPARK, 10f + rnd() * 14f)
            }
            Reaction.ACTIVITY -> emit(2, 2.5f) {
                Particle(640f + rnd() * 400f, 280f + rnd() * 300f, (rnd() - 0.5f) * 20f, -20f - rnd() * 20f,
                    1.2f, 1.2f, K_SPARK, 9f + rnd() * 8f)
            }
            else -> {}
        }
        if (f.zzz) {
            emit(3, 0.7f) { Particle(930f, 360f, 18f + rnd() * 10f, -34f, 2.6f, 2.6f, K_ZZZ, 22f + rnd() * 6f) }
        }
        if (f.tear) {
            emit(4, 0.5f) { Particle(692f, 505f, 0f, 20f, 1.2f, 1.2f, K_TEAR, 6f) }
        }
    }

    val iter = h.parts.iterator()
    while (iter.hasNext()) {
        val p = iter.next()
        p.life -= dt
        if (p.life <= 0f) {
            iter.remove()
            continue
        }
        if (p.kind == K_CRUMB || p.kind == K_TEAR) p.vy += 600f * dt
        p.x += p.vx * dt
        p.y += p.vy * dt
    }
    if (!s.animationsOn && h.parts.isNotEmpty()) h.parts.clear()
}

// ---------------------------------------------------------------------------
// Dessin
// ---------------------------------------------------------------------------

private class Xf(val s: Float, val ox: Float, val oy: Float)

private fun sceneXf(w: Float, h: Float, region: Rect?): Xf {
    val r = region ?: Rect(0f, 0f, SCENE_W, SCENE_H)
    val s = max(w / r.width, h / r.height)
    val ox = (w - r.width * s) / 2f - r.left * s
    val oy = (h - r.height * s) / 2f - r.top * s
    return Xf(s, ox, oy)
}

/** Dessine une image en pleine qualité (filtrage de haute qualité) à la position donnée. */
private fun DrawScope.drawBitmapHQ(img: ImageBitmap, x: Int, y: Int) {
    val sz = IntSize(img.width, img.height)
    drawImage(img, IntOffset.Zero, sz, IntOffset(x, y), sz, filterQuality = FilterQuality.High)
}

private fun DrawScope.drawEye(e: EyeGeo, lid: ImageBitmap, cover: Float, happy: Boolean) {
    val c = if (happy) 1f else cover
    if (c < 0.03f) return
    val w = lid.width.toFloat()
    val h = lid.height.toFloat()
    val edge = if (c >= 0.999f) h else h * (0.10f + 0.80f * c)
    clipRect(left = e.patchX, top = e.patchY, right = e.patchX + w, bottom = e.patchY + edge) {
        drawBitmapHQ(lid, e.patchX.toInt(), e.patchY.toInt())
    }
    rotate(e.rot * RAD_TO_DEG, Offset(e.cx, e.cy)) {
        val top = -e.ry * 0.95f
        val bot = e.ry * 0.55f
        val y = top + (bot - top) * c
        val hw = e.rx * 0.92f
        val path = Path()
        if (happy) {
            path.moveTo(e.cx - hw, e.cy + 6f)
            path.quadraticBezierTo(e.cx, e.cy - 30f, e.cx + hw, e.cy + 6f)
        } else {
            path.moveTo(e.cx - hw, e.cy + y - 3f)
            path.quadraticBezierTo(e.cx, e.cy + y + 15f, e.cx + hw, e.cy + y - 3f)
        }
        drawPath(path, LASH, style = Stroke(width = 5f, cap = StrokeCap.Round, join = StrokeJoin.Round))
        val dir = if (e.outerLeft) -1f else 1f
        for (i in 0..2) {
            val bx = e.cx + dir * hw * (1f - i * 0.16f)
            val by = e.cy + if (happy) (4f - i * 2f) else (y - 1f + i * 3f)
            val ex = bx + dir * 13f
            val ey = by + if (happy) (-9f + i * 2f) else (9f + i * 3f)
            drawLine(LASH, Offset(bx, by), Offset(ex, ey), strokeWidth = 3f, cap = StrokeCap.Round)
        }
    }
}

private fun DrawScope.drawMouth(f: Face, cover: ImageBitmap) {
    if (f.mouth == Mouth.OPEN) return
    drawBitmapHQ(cover, 770, 475)
    val cx = 832f
    val cy = 517f
    rotate(-0.06f * RAD_TO_DEG, Offset(cx, cy)) {
        val line = Stroke(width = 4f, cap = StrokeCap.Round, join = StrokeJoin.Round)
        when (f.mouth) {
            Mouth.SMILE -> {
                val p = Path()
                p.moveTo(cx - 34f, cy - 6f)
                p.quadraticBezierTo(cx, cy + 22f, cx + 34f, cy - 6f)
                drawPath(p, MOUTH_LINE, style = line)
            }
            Mouth.SAD -> {
                val p = Path()
                p.moveTo(cx - 26f, cy + 10f)
                p.quadraticBezierTo(cx, cy - 8f, cx + 26f, cy + 10f)
                drawPath(p, MOUTH_LINE, style = line)
            }
            Mouth.O -> {
                drawOval(O_FILL, Offset(cx - 12f, cy - 11f), Size(24f, 30f))
                drawOval(MOUTH_LINE, Offset(cx - 12f, cy - 11f), Size(24f, 30f), style = line)
            }
            Mouth.BIG -> {
                val o = f.mouthOpen.coerceIn(0.05f, 1f)
                val yb = cy - 8f + 42f * o
                val p = Path()
                p.moveTo(cx - 38f, cy - 8f)
                p.quadraticBezierTo(cx, cy - 2f, cx + 38f, cy - 8f)
                p.quadraticBezierTo(cx + 30f, yb, cx, yb)
                p.quadraticBezierTo(cx - 30f, yb, cx - 38f, cy - 8f)
                p.close()
                drawPath(p, MOUTH_FILL)
                if (o > 0.3f) {
                    drawOval(TONGUE, Offset(cx - 16f, yb - 10f * o - 8f * o), Size(32f, 16f * o))
                }
                drawPath(p, MOUTH_LINE, style = line)
            }
            Mouth.FLAT -> drawLine(MOUTH_LINE, Offset(cx - 22f, cy + 4f), Offset(cx + 22f, cy + 4f), 4f, StrokeCap.Round)
            Mouth.OPEN -> {}
        }
    }
}

private fun DrawScope.drawBlush(alpha: Float) {
    val spots = listOf(Offset(676f, 522f) to 40f, Offset(978f, 470f) to 36f)
    for ((c, r) in spots) {
        drawCircle(
            brush = Brush.radialGradient(
                colors = listOf(Color(0xFFFF5FA0).copy(alpha = 0.40f * alpha), Color.Transparent),
                center = c, radius = r,
            ),
            radius = r, center = c,
        )
    }
}

private fun DrawScope.drawAccessory(id: String) {
    when (id) {
        "acc_crown" -> {
            val cx = 782f
            val cy = 290f
            val w = 100f
            val h = w * 0.42f
            rotate(-0.07f * RAD_TO_DEG, Offset(cx, cy)) {
                val p = Path()
                p.moveTo(cx - w / 2f, cy)
                p.lineTo(cx - w / 2f, cy - h * 0.55f)
                p.lineTo(cx - w / 4f, cy - h * 0.2f)
                p.lineTo(cx, cy - h)
                p.lineTo(cx + w / 4f, cy - h * 0.2f)
                p.lineTo(cx + w / 2f, cy - h * 0.55f)
                p.lineTo(cx + w / 2f, cy)
                p.close()
                drawPath(
                    p,
                    Brush.verticalGradient(listOf(Color(0xFFFFF0A8), Color(0xFFE8A92C)), startY = cy - h, endY = cy),
                )
                drawPath(p, Color(0xFF9A6410), style = Stroke(width = 3f, join = StrokeJoin.Round))
                drawCircle(Color(0xFFFF5FD2), w * 0.045f, Offset(cx - w / 2f, cy - h * 0.55f))
                drawCircle(Color(0xFFFF5FD2), w * 0.045f, Offset(cx, cy - h))
                drawCircle(Color(0xFFFF5FD2), w * 0.045f, Offset(cx + w / 2f, cy - h * 0.55f))
                drawCircle(Color(0xFF7BE0FF), w * 0.05f, Offset(cx, cy - h * 0.38f))
            }
        }
        "acc_bow" -> {
            val cx = 905f
            val cy = 342f
            val s = 34f
            rotate(0.25f * RAD_TO_DEG, Offset(cx, cy)) {
                for (d in listOf(-1f, 1f)) {
                    val p = Path()
                    p.moveTo(cx, cy)
                    p.quadraticBezierTo(cx + d * s * 0.9f, cy - s * 0.9f, cx + d * s * 1.15f, cy - s * 0.1f)
                    p.quadraticBezierTo(cx + d * s * 0.9f, cy + s * 0.8f, cx, cy)
                    p.close()
                    drawPath(p, Color(0xFFFF5FA8))
                    drawPath(p, Color(0xFFA0165F), style = Stroke(width = 3f, join = StrokeJoin.Round))
                }
                drawCircle(Color(0xFFFF8CC4), s * 0.28f, Offset(cx, cy))
                drawCircle(Color(0xFFA0165F), s * 0.28f, Offset(cx, cy), style = Stroke(width = 3f))
            }
        }
        "acc_flower" -> {
            val cx = 648f
            val cy = 402f
            val s = 30f
            for (i in 0..4) {
                val a = i * PIF * 2f / 5f
                val px = cx + cos(a) * s * 0.55f
                val py = cy + sin(a) * s * 0.55f
                rotate(a * RAD_TO_DEG, Offset(px, py)) {
                    drawOval(Color(0xFFFFF3A6), Offset(px - s * 0.42f, py - s * 0.3f), Size(s * 0.84f, s * 0.6f))
                    drawOval(
                        Color(0xFFE0A030), Offset(px - s * 0.42f, py - s * 0.3f), Size(s * 0.84f, s * 0.6f),
                        style = Stroke(width = 2f),
                    )
                }
            }
            drawCircle(Color(0xFFFF8A3D), s * 0.3f, Offset(cx, cy))
        }
        else -> {}
    }
}

private fun heartPath(cx: Float, cy: Float, s: Float): Path {
    val p = Path()
    p.moveTo(cx, cy + s * 0.35f)
    p.cubicTo(cx - s * 0.9f, cy - s * 0.2f, cx - s * 0.5f, cy - s * 0.95f, cx, cy - s * 0.4f)
    p.cubicTo(cx + s * 0.5f, cy - s * 0.95f, cx + s * 0.9f, cy - s * 0.2f, cx, cy + s * 0.35f)
    p.close()
    return p
}

private fun sparklePath(cx: Float, cy: Float, s: Float): Path {
    val p = Path()
    p.moveTo(cx, cy - s)
    p.quadraticBezierTo(cx + s * 0.12f, cy - s * 0.12f, cx + s, cy)
    p.quadraticBezierTo(cx + s * 0.12f, cy + s * 0.12f, cx, cy + s)
    p.quadraticBezierTo(cx - s * 0.12f, cy + s * 0.12f, cx - s, cy)
    p.quadraticBezierTo(cx - s * 0.12f, cy - s * 0.12f, cx, cy - s)
    p.close()
    return p
}

private fun DrawScope.drawParticle(p: Particle) {
    val a = (p.life / p.maxLife).coerceIn(0f, 1f)
    when (p.kind) {
        K_HEART -> drawPath(heartPath(p.x, p.y, p.size), Color(0xFFFF6FB5).copy(alpha = a))
        K_CRUMB -> drawCircle(Color(0xFFE0A86A).copy(alpha = a), p.size, Offset(p.x, p.y))
        K_SPARK -> drawPath(sparklePath(p.x, p.y, p.size), Color(0xFFFFEBB0).copy(alpha = a))
        K_TEAR -> drawCircle(Color(0xFFA6E3FF).copy(alpha = a), p.size, Offset(p.x, p.y))
        K_ZZZ -> {
            val z = p.size
            val path = Path()
            path.moveTo(p.x, p.y)
            path.lineTo(p.x + z, p.y)
            path.lineTo(p.x, p.y + z)
            path.lineTo(p.x + z, p.y + z)
            drawPath(
                path, Color(0xFFE6D8FF).copy(alpha = a),
                style = Stroke(width = 4f, cap = StrokeCap.Round, join = StrokeJoin.Round),
            )
        }
    }
}

// ---------------------------------------------------------------------------
// Composable
// ---------------------------------------------------------------------------

/**
 * Dessine la scène et anime le visage de Nyxie selon son état.
 *
 * @param region zone de l'image à afficher (null = image entière, recadrée au centre)
 * @param forcedFace expression figée (miniatures de la galerie) : pas d'animation
 */
@Composable
fun NyxieScene(
    state: GameState,
    reaction: Reaction,
    modifier: Modifier = Modifier,
    region: Rect? = null,
    forcedFace: Face? = null,
    onTapNyxie: (() -> Unit)? = null,
) {
    val assets = LocalAssets.current
    val stateRef by rememberUpdatedState(state)
    val reactionRef by rememberUpdatedState(reaction)
    val tapRef by rememberUpdatedState(onTapNyxie)
    val holder = remember { Holder() }
    val tick = remember { mutableFloatStateOf(0f) }

    LaunchedEffect(forcedFace) {
        if (forcedFace != null) {
            holder.face = forcedFace
            holder.eye = forcedFace.eye
            holder.blink = 0f
            tick.floatValue = 1f
        } else {
            var last = 0L
            while (true) {
                withFrameNanos { nanos ->
                    if (last == 0L) last = nanos
                    val dt = ((nanos - last) / 1_000_000_000f).coerceIn(0f, 0.1f)
                    last = nanos
                    val t = nanos / 1_000_000_000f
                    step(holder, stateRef, reactionRef, t, dt)
                    tick.floatValue = t
                }
            }
        }
    }

    val tapModifier = if (onTapNyxie != null) {
        Modifier.pointerInput(region) {
            detectTapGestures { off ->
                val xf = sceneXf(size.width.toFloat(), size.height.toFloat(), region)
                val sx = (off.x - xf.ox) / xf.s
                val sy = (off.y - xf.oy) / xf.s
                if (sx > 480f && sx < 1300f && sy > 230f && sy < 820f) tapRef?.invoke()
            }
        }
    } else {
        Modifier
    }

    Canvas(modifier = modifier.then(tapModifier)) {
        val t = tick.floatValue
        val xf = sceneXf(size.width, size.height, region)
        val s = stateRef
        val face = if (forcedFace != null) forcedFace else holder.face
        val animated = forcedFace == null && s.animationsOn
        val breath = if (animated) 1f + 0.005f * sin(t * 1.6f) else 1f
        val jumpY = if (animated) holder.jump else 0f
        drawRect(Color(0xFF0D0720))
        withTransform({
            translate(xf.ox, xf.oy)
            scale(xf.s, xf.s, Offset.Zero)
            translate(0f, jumpY)
            scale(breath, breath, Offset(836f, 800f))
        }) {
            drawBitmapHQ(assets.scene, 0, 0)
            if (face.blush) drawBlush(1f)
            val cover = if (face.happyEyes) 1f else (1f - min(holder.eye, 1f - holder.blink)).coerceIn(0f, 1f)
            drawEye(EYE_L, assets.lidL, cover, face.happyEyes)
            drawEye(EYE_R, assets.lidR, cover, face.happyEyes)
            drawMouth(face, assets.mouthCover)
            drawAccessory(s.accessory)
            for (p in holder.parts) drawParticle(p)
        }
    }
}

/** Petit avatar rond : le visage de Nyxie recadré dans l'image de la scène. */
@Composable
fun NyxieAvatar(modifier: Modifier = Modifier) {
    val assets = LocalAssets.current
    Canvas(modifier = modifier) {
        val side = min(size.width, size.height).toInt()
        drawImage(
            image = assets.scene,
            srcOffset = androidx.compose.ui.unit.IntOffset(620, 330),
            srcSize = androidx.compose.ui.unit.IntSize(420, 420),
            dstSize = androidx.compose.ui.unit.IntSize(side, side),
            filterQuality = FilterQuality.High,
        )
    }
}
