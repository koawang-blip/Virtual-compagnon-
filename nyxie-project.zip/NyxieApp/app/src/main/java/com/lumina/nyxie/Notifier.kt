package com.lumina.nyxie

import android.app.AlarmManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import java.util.Calendar
import kotlin.math.max
import kotlin.math.min

/**
 * Rappels doux de Nyxie : une alarme est programmée quand on quitte l'application,
 * à l'heure où elle aura probablement faim ou besoin d'attention. Pas de service en
 * arrière-plan, pas de permission spéciale, rien n'est envoyé sur internet.
 */
object Notifier {
    private const val CHANNEL = "nyxie_care"
    private const val REQ = 4242
    private const val PREFS = "nyxie_notif"

    private fun alarmIntent(c: Context): PendingIntent =
        PendingIntent.getBroadcast(
            c, REQ, Intent(c, NyxieReceiver::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
        )

    fun cancel(c: Context) {
        try {
            (c.getSystemService(Context.ALARM_SERVICE) as AlarmManager).cancel(alarmIntent(c))
        } catch (e: Exception) {
        }
    }

    /** Évite la nuit : si l'heure tombe entre 22 h et 8 h, on décale à 9 h. */
    private fun outOfQuietHours(at: Long): Long {
        val cal = Calendar.getInstance().apply { timeInMillis = at }
        val h = cal.get(Calendar.HOUR_OF_DAY)
        if (h in 8..21) return at
        if (h >= 22) cal.add(Calendar.DAY_OF_YEAR, 1)
        cal.set(Calendar.HOUR_OF_DAY, 9)
        cal.set(Calendar.MINUTE, 0)
        cal.set(Calendar.SECOND, 0)
        return cal.timeInMillis
    }

    /** Programme le prochain rappel d'après l'état enregistré. [reset] remet à zéro le compteur de rappels. */
    fun schedule(c: Context, s: GameState, reset: Boolean) {
        cancel(c)
        if (!s.notifOn) return
        val sp = c.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        if (reset) sp.edit().putInt("count", 0).apply()
        if (sp.getInt("count", 0) >= 3) return          // pas plus de 3 rappels sans que tu reviennes
        val hungerRate = if (s.sleeping) 0.05f else 0.15f
        val affRate = if (s.sleeping) 0.02f else 0.09f
        val hHunger = (s.hunger - 0.25f) / hungerRate
        val hAff = (s.affection - 0.25f) / affRate
        val hours = min(10f, max(2f, min(hHunger, hAff)))
        val at = outOfQuietHours(System.currentTimeMillis() + (hours * 3_600_000f).toLong())
        try {
            val am = c.getSystemService(Context.ALARM_SERVICE) as AlarmManager
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, alarmIntent(c))
        } catch (e: Exception) {
        }
    }

    private fun message(s: GameState): Pair<String, String> {
        val n = s.name
        return when {
            s.hunger < 0.30f -> "$n a faim 🍽️" to "Son petit ventre gargouille… viens lui donner à manger !"
            s.affection < 0.30f -> "$n s'ennuie 💜" to "Un petit câlin lui ferait tellement plaisir."
            s.energy < 0.25f -> "$n est fatiguée 😴" to "Elle aimerait bien faire un petit dodo avec toi."
            else -> "$n pense à toi ✨" to "Elle aimerait te raconter quelque chose."
        }
    }

    fun post(c: Context) {
        val s0 = Store.load(c)
        if (!s0.notifOn || s0.lastSeen == 0L) return
        val s = decay(s0, System.currentTimeMillis() - s0.lastSeen)
        val (title, text) = message(s)
        val nm = c.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(
                NotificationChannel(CHANNEL, "Rappels de Nyxie", NotificationManager.IMPORTANCE_DEFAULT),
            )
        }
        val open = PendingIntent.getActivity(
            c, 1, Intent(c, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
        )
        val n = NotificationCompat.Builder(c, CHANNEL)
            .setSmallIcon(R.drawable.ic_notif)
            .setContentTitle(title)
            .setContentText(text)
            .setStyle(NotificationCompat.BigTextStyle().bigText(text))
            .setContentIntent(open)
            .setAutoCancel(true)
            .build()
        try {
            if (NotificationManagerCompat.from(c).areNotificationsEnabled()) {
                NotificationManagerCompat.from(c).notify(REQ, n)
            }
        } catch (e: SecurityException) {
        }
        val sp = c.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        sp.edit().putInt("count", sp.getInt("count", 0) + 1).apply()
        // Prochain rappel éventuel, à partir de l'état déjà dégradé.
        schedule(c, s.copy(hunger = max(s.hunger, 0.3f), affection = max(s.affection, 0.3f)), reset = false)
    }
}

class NyxieReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        Notifier.post(context.applicationContext)
    }
}
