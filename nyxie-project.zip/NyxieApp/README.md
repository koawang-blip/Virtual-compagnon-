# Nyxie, compagnon virtuel (version 2)

Application Android en Jetpack Compose. Tout fonctionne sur le téléphone : aucune IA distante, aucun compte.

## Ce qui est réellement fonctionnel

- **Jauges** (faim, énergie, affection, humeur) qui évoluent avec le temps, même application fermée.
- **Nourrir** (choix de la nourriture dans le sac), **Caresser**, **Jouer**, **Parler**, **Activité** (4 activités chronométrées), **Cadeau** (un toutes les 8 h).
- **Visage animé en direct** : paupières qui se ferment et clignent, yeux rieurs, bouche qui s'ouvre, mâche, parle, sourit, boude, bâille, rougit, pleure quand elle est triste, dort avec des « Zzz ».
- **Particules** : cœurs, miettes, étincelles, larmes.
- **Discussion** locale avec réponses selon l'humeur et ce que tu écris, plus saisie vocale (micro).
- **Soins** : repas, bain de lune, brossage, dormir / réveiller.
- **Jeux** : Étoiles filantes et Mémoire lunaire, avec records, pièces et expérience.
- **Personnalisation** : accessoires (fleur, nœud, couronne) et thèmes de couleur, à acheter puis équiper.
- **Galerie** de 6 souvenirs à débloquer, **Inventaire et boutique**, **Évolution** par niveau, **Paramètres** (nom, sons, animations, réinitialisation).
- **Sauvegarde automatique.**

## Compiler

### Avec Android Studio
Ouvrir le dossier `NyxieApp`, attendre la synchronisation, puis Build > Build APK(s).
L'APK est dans `app/build/outputs/apk/debug/app-debug.apk`.

### Sans ordinateur, avec GitHub (depuis le téléphone)
1. Créer un dépôt GitHub vide.
2. Add file > Upload files : envoyer `nyxie-project.zip` (sans le dézipper) et valider.
3. Add file > Create new file : nommer `.github/workflows/build.yml` et coller le contenu du fichier `build.yml` fourni.
4. Onglet Actions > « Compiler Nyxie » > Run workflow.
5. Quand c'est vert, ouvrir l'exécution et télécharger l'artefact `Nyxie-APK`.

## Installer
Copier `app-debug.apk` sur le téléphone, l'ouvrir et autoriser l'installation.
Si l'ancienne version de Nyxie est installée avec une autre signature, la désinstaller d'abord.

## Rythme du jeu
Éveillée : faim -15 %/h, énergie -10 %/h, affection -9 %/h. Endormie : énergie +50 %/h.
Le niveau suivant demande 50 × niveau points d'expérience.
