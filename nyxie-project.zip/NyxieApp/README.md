# Nyxie, compagnon virtuel (version 2)

Application Android en Jetpack Compose. Tout fonctionne sur le téléphone : aucune IA distante, aucun compte.

## Ce qui est réellement fonctionnel

- **Jauges** (faim, énergie, affection, humeur) qui évoluent avec le temps, même application fermée.
- **Nourrir** (choix de la nourriture dans le sac), **Caresser**, **Jouer**, **Parler**, **Activité** (4 activités chronométrées), **Cadeau** (un toutes les 8 h).
- **Visage animé en direct** : paupières qui se ferment et clignent, yeux rieurs, bouche qui s'ouvre, mâche, parle, sourit, boude, bâille, rougit, pleure quand elle est triste, dort avec des « Zzz ».
- **Particules** : cœurs, miettes, étincelles, larmes.
- **Discussion** locale avec réponses selon l'humeur et ce que tu écris, plus saisie vocale (micro).
- **Soins** : repas, bain de lune, brossage, dormir / réveiller.
- **Jeux** : Étoiles filantes et Mémoire lunaire, avec records, pièces et expérience.
- **Personnalisation** : accessoires (fleur, nœud, couronne) et thèmes de couleur, à acheter puis équiper.
- **Galerie** de 6 souvenirs à débloquer, **Inventaire et boutique**, **Évolution** par niveau, **Paramètres** (nom, sons, animations, réinitialisation).
- **Sauvegarde automatique.**

## Compiler

### Avec Android Studio
Ouvrir le dossier `NyxieApp`, attendre la synchronisation, puis Build > Build APK(s).
L'APK est dans `app/build/outputs/apk/debug/app-debug.apk`.

### Sans ordinateur, avec GitHub (depuis le téléphone)
1. Créer un dépôt GitHub vide.
2. Add file > Upload files : envoyer `nyxie-project.zip` (sans le dézipper) et valider.
3. Add file > Create new file : nommer `.github/workflows/build.yml` et coller le contenu du fichier `build.yml` fourni.
4. Onglet Actions > « Compiler Nyxie » > Run workflow.
5. Quand c'est vert, ouvrir l'exécution et télécharger l'artefact `Nyxie-APK`.

## Installer
Copier `app-debug.apk` sur le téléphone, l'ouvrir et autoriser l'installation.
Si l'ancienne version de Nyxie est installée avec une autre signature, la désinstaller d'abord.

## Rythme du jeu
Éveillée : faim -15 %/h, énergie -10 %/h, affection -9 %/h. Endormie : énergie +50 %/h.
Le niveau suivant demande 50 × niveau points d'expérience.

## Mise à jour 2.1
- Yeux fermés corrigés : les rustines de peau recouvrent maintenant tout l'œil d'origine (plus de cils fantômes),
  la ligne de paupière est effilée avec cils recourbés et ombre douce, et le clignement suit la vraie forme de l'œil.
- Clé de signature fixe (`app/debug.keystore`) : à partir de cette version, une nouvelle compilation
  s'installe par-dessus l'ancienne **sans perdre la progression**.
  Cette version-ci est signée avec une nouvelle clé : désinstaller l'ancienne Nyxie une seule fois avant de l'installer.

## Mise à jour 2.2 — boutique agrandie

- Nouveaux aliments, boissons, jouets (peluche, cerf-volant, boîte à musique…).
- Accessoires par emplacement : tête, visage, cou, et auras animées (étoiles, cœurs, bulles). On peut en porter un par emplacement.
- Ambiances animées (aurore, lucioles, pétales, neige, étoiles filantes…) et thèmes de couleur supplémentaires.
- Boutique à onglets (Inventaire > Boutique, et Personnalisation).
- Dessins des accessoires générés par `tools/make_acc.py` (sortie : `AccArt.kt`).

## Mise à jour 2.3

- Niveau maximum porté à 50 (XP par niveau plafonnée à 600), nouveaux rangs : Reine des étoiles (30), Dragon cosmique (40), Légende de la nuit (50).

## Mise à jour 2.4

- Cache de peau de la bouche agrandi : plus de traits sombres aux coins de la bouche d'origine.

## Mise à jour 2.5 — bruitages

- Sons de Nyxie (ronronnement, miaulement, croquement, rire, éclaboussures, bâillement, étincelles, pièces…) dans `res/raw/snd_*.wav`, joués selon les actions.
- Générés par `tools/make_sounds.py` (synthèse), remplaçables par de vrais enregistrements en gardant les mêmes noms de fichiers.
- Réglage : Paramètres > Sons de l'application.

## Mise à jour 2.6 — notifications

- Rappels doux de Nyxie (faim, ennui, fatigue) programmés quand on quitte l'appli, jamais entre 22 h et 8 h, 3 maximum sans retour.
- Réglage : Paramètres > Notifications de Nyxie. Permission demandée une fois (Android 13+).

## Mise à jour 2.7 — retour après absence

- Selon la durée d'absence (30 min, 3 h, 12 h) Nyxie réagit, boude un instant après 12 h, puis offre un cadeau de retrouvailles.

## Mise à jour 2.8 — quêtes quotidiennes

- Onglet « Quêtes » : 3 quêtes par jour, récompenses en pièces, série de jours consécutifs et coffre du jour.

## Mise à jour 2.9 — mode photo

- Onglet « Mode photo » : interface masquée, Nyxie en plein écran, 5 cadres, déclencheur avec bruit d'obturateur, enregistrement dans Images/Nyxie et bouton Partager.

## Mise à jour 3.0 — tics et humeurs

- Petits tics aléatoires selon l'humeur : curiosité, rire, clignement lent, bâillement, regard autour, secousse, fierté, bouderie.
- Légère inclinaison de la tête, et vers le doigt quand on touche Nyxie.

## Mise à jour 3.1 — widget

- Widget « Nyxie » pour l'écran d'accueil : visage, niveau, humeur et jauges faim / énergie / affection. Un tap ouvre l'application. Mis à jour à la fermeture de l'appli et toutes les 30 min.

## Mise à jour 3.2 — icône et musique

- Vraie icône d'application (adaptative) à l'effigie de Nyxie.
- Musique d'ambiance (berceuse en boucle, générée par `tools/make_music.py`), réglable dans Paramètres, mise en pause quand on quitte l'appli.

## Mise à jour 3.3

- La bulle de dialogue est déplacée au-dessus des boutons (à gauche) et rendue plus compacte pour ne plus cacher le visage.

## Mise à jour 3.4

- Bulle de dialogue remise en haut, plus petite et semi-transparente.

## Mise à jour 3.5

- Retrait des boutons de test (pièces / tout débloquer) des Paramètres.
